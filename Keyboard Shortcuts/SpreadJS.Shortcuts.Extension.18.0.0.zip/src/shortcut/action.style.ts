import { Commands, executeCommand, IShortcutActionOptionBase, ShortcutActionBase } from "../shell/action.base";
import * as GC from "@grapecity/spread-sheets";
import { Util } from "../common/util";
const SET_CELL_BOLD = 'setCellBold',
    SET_CELL_ITALICIZE = 'setCellItalicize',
    SET_CELL_UNDERLINE = 'setCellUnderline',
    SET_NUMBER_TO_PERCENT = 'setNumberToPercent';


const FONT_WEIGHT = 'font-weight',
    FONT_BOLD = 'bold',
    FONT_STYLE = 'font-style',
    FONT_NORMAL = 'normal',
    FONT_ITALIC = 'italic';

const VerticalPosition = GC.Spread.Sheets.VerticalPosition;
const HorizontalPosition = GC.Spread.Sheets.HorizontalPosition;


interface ISetCellStyleActionOption extends IShortcutActionOptionBase {
    boldState?: boolean;
    italicizeState?: boolean;
    underlineType?: number;
    handler?: (cell: GC.Spread.Sheets.CellRange) => void;
}

interface IFontInfo {
    fontStyle: string;
    fontWeight: string;
    lineHeight: string;
}

class SetCellStyleAction extends ShortcutActionBase<ISetCellStyleActionOption> {
    executeImp () {
        let self = this;
        let sheet = self.getSheet();
        let option = self._options as ISetCellStyleActionOption;
        let handler = option.handler && option.handler.bind(self);
        let activeRow = option.activeRowIndex ?? sheet.getActiveRowIndex(), activeCol = option.activeColIndex ?? sheet.getActiveColumnIndex();
        if (handler) {
            this.setCellStyle(handler);
        }
        sheet.showCell(activeRow, activeCol, VerticalPosition.nearest, HorizontalPosition.nearest);
        return true;
    }
}

Commands[SET_CELL_BOLD] = {
    canUndo: true,
    execute: function (context: GC.Spread.Sheets.Workbook, options: ISetCellStyleActionOption, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (sheet && Util.needCheckProtectionOptions(sheet)) {
            if (!(sheet.options.protectionOptions as any).formatCells) {
                return false;
            }
        }
        options.cmd = SET_CELL_BOLD;
        let selections = options.selections || sheet.getSelections(), activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(),
            activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
        if (selections.length > 0) {
            let font = Util.getActiveCellStyle(sheet, activeRowIndex, activeColIndex ).font;
            let boldState = false;
            if (font) {
                let fontWeight = Util.parseFont(font).fontWeight;
                if (fontWeight !== 'normal') {
                    boldState = true;
                }
            }
            options.boldState = boldState;
            options.handler = function (cell: GC.Spread.Sheets.CellRange) {
                let fontWeight = (this as any)._options.boldState;
                let needAdjustRange;
                if (cell.row === -1 || cell.col === -1) {
                    if (cell.row === -1 && cell.col === -1) {
                        for (let col = 0; col < sheet.getColumnCount(); col++) {
                            let colStyle = sheet.getStyle(-1, col);
                            if (!colStyle) {
                                continue;
                            }
                            colStyle.fontWeight = undefined;
                            sheet.setStyle(-1, col, colStyle);
                        }
                    }
                    let usedRange = sheet.getUsedRange(GC.Spread.Sheets.UsedRangeType.style);
                    if (usedRange) {
                        let selectedRange = new GC.Spread.Sheets.Range(cell.row, cell.col, cell.rowCount, cell.colCount);
                        let adjustRange = usedRange.getIntersect(selectedRange, cell.sheet.getRowCount(), cell.sheet.getColumnCount());
                        if (adjustRange) {
                            needAdjustRange = sheet.getRange(adjustRange.row, adjustRange.col, adjustRange.rowCount, adjustRange.colCount);
                        }
                    }
                }
                let boldString = fontWeight ? FONT_NORMAL : FONT_BOLD;
                if ((cell as any).fontWeight) {
                    (cell as any).fontWeight(boldString);
                    if (needAdjustRange && needAdjustRange.fontWeight) {
                        needAdjustRange.fontWeight(boldString);
                    }
                } else {
                    for (let row = cell.row; row < cell.row + cell.rowCount; row++) {
                        for (let col = cell.col; col < cell.col + cell.colCount; col++) {
                            let currentCellStyle = sheet.getActualStyle(row, col);
                            let currentFont = currentCellStyle.font;
                            currentFont = (this as any).getFontStyle(currentFont, FONT_WEIGHT, boldString);
                            currentCellStyle.font = currentFont;
                            sheet.setStyle(row, col, currentCellStyle);
                        }
                    }
                }
            };
            return executeCommand(context, SetCellStyleAction, options, isUndo);
        }
        return false;
    }
};

Commands[SET_CELL_ITALICIZE] = {
    canUndo: true,
    execute: function (context: GC.Spread.Sheets.Workbook, options: ISetCellStyleActionOption, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (sheet && Util.needCheckProtectionOptions(sheet)) {
            if (!(sheet.options.protectionOptions as any).formatCells) {
                return false;
            }
        }
        options.cmd = SET_CELL_ITALICIZE;
        let selections = options.selections || sheet.getSelections(), activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(),
            activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
        if (selections.length > 0) {
            let style = Util.getActiveCellStyle(sheet, activeRowIndex, activeColIndex);
            let font = style && style.font, italicizeState = false;
            if (font) {
                let fontStyle = Util.parseFont(font).fontStyle;
                if (fontStyle.indexOf(FONT_ITALIC) !== -1) {
                    italicizeState = true;
                }
            }
            options.italicizeState = italicizeState;
            options.handler = function (cellRange: GC.Spread.Sheets.CellRange) {
                let fontStyle = (this as any)._options.italicizeState;
                let needAdjustRange;

                if (cellRange.row === -1 || cellRange.col === -1) {
                    if (cellRange.row === -1 && cellRange.col === -1) {
                        for (let col = 0; col < sheet.getColumnCount(); col++) {
                            let colStyle = sheet.getStyle(-1, col);
                            if (!colStyle) {
                                continue;
                            }
                            colStyle.fontStyle = undefined;
                            sheet.setStyle(-1, col, colStyle);
                        }
                    }
                    let usedRange = sheet.getUsedRange(GC.Spread.Sheets.UsedRangeType.style);
                    if (usedRange) {
                        let selectedRange = new GC.Spread.Sheets.Range(cellRange.row, cellRange.col, cellRange.rowCount, cellRange.colCount);
                        let adjustRange = usedRange.getIntersect(selectedRange, cellRange.sheet.getRowCount(), cellRange.sheet.getColumnCount());
                        if (adjustRange) {
                            needAdjustRange = sheet.getRange(adjustRange.row, adjustRange.col, adjustRange.rowCount, adjustRange.colCount);
                        }
                    }
                }
                let fontStyleString = fontStyle ? FONT_NORMAL : FONT_ITALIC;
                if ((cellRange as any).fontStyle) {
                    (cellRange as any).fontStyle(fontStyleString);

                    if (needAdjustRange && needAdjustRange.fontStyle) {
                        needAdjustRange.fontStyle(fontStyleString);
                    }
                } else {
                    for (let row = cellRange.row; row < cellRange.row + cellRange.rowCount; row++) {
                        for (let col = cellRange.col; col < cellRange.col + cellRange.colCount; col++) {
                            let currentCellStyle = sheet.getActualStyle(row, col);
                            let currentFont = currentCellStyle.font;
                            currentFont = (this as any).getFontStyle(currentFont, FONT_STYLE, fontStyleString);
                            currentCellStyle.font = currentFont;
                            sheet.setStyle(row, col, currentCellStyle);
                        }
                    }
                }
            };
            return executeCommand(context, SetCellStyleAction, options, isUndo);
        }
        return false;
    }
};

Commands[SET_CELL_UNDERLINE] = {
    canUndo: true,
    execute: function (context: GC.Spread.Sheets.Workbook, options: ISetCellStyleActionOption, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (sheet && Util.needCheckProtectionOptions(sheet)) {
            if (!(sheet.options.protectionOptions as any).formatCells) {
                return false;
            }
        }
        options.cmd = SET_CELL_UNDERLINE;
        let selections = options.selections || sheet.getSelections(), activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(),
            activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
        if (selections.length > 0) {
            let style = Util.getActiveCellStyle(sheet, activeRowIndex, activeColIndex);
            let underline = style && style.textDecoration;
            let textDecorationType = GC.Spread.Sheets.TextDecorationType;
            if (underline) {
                options.underlineType = textDecorationType.none;
            } else {
                options.underlineType = textDecorationType.underline;
            }
            options.handler = function (cellRange: GC.Spread.Sheets.CellRange) {
                let underType = (this as any)._options.underlineType;
                let needAdjustRange;

                if (cellRange.row === -1 || cellRange.col === -1) {
                    let usedRange = sheet.getUsedRange(GC.Spread.Sheets.UsedRangeType.style);
                    if (usedRange) {
                        let selectedRange = new GC.Spread.Sheets.Range(cellRange.row, cellRange.col, cellRange.rowCount, cellRange.colCount);
                        let adjustRange = usedRange.getIntersect(selectedRange, cellRange.sheet.getRowCount(), cellRange.sheet.getColumnCount());
                        if (adjustRange) {
                            needAdjustRange = sheet.getRange(adjustRange.row, adjustRange.col, adjustRange.rowCount, adjustRange.colCount);
                        }
                    }
                }

                cellRange.textDecoration(underType);

                if (needAdjustRange && needAdjustRange.textDecoration) {
                    needAdjustRange.textDecoration(underType);
                }
            };
            return executeCommand(context, SetCellStyleAction, options, isUndo);
        }
        return false;
    }
};

Commands[SET_NUMBER_TO_PERCENT] = {
    canUndo: true,
    execute: function (context: GC.Spread.Sheets.Workbook, options: ISetCellStyleActionOption, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (sheet && Util.needCheckProtectionOptions(sheet)) {
            if (!(sheet.options.protectionOptions as any).formatCells) {
                return false;
            }
        }
        options.cmd = SET_NUMBER_TO_PERCENT;
        let selections = options.selections || sheet.getSelections();
        if (selections.length) {
            options.handler = function (cell: GC.Spread.Sheets.CellRange) {
                cell.formatter("0%");
            };
            return executeCommand(context, SetCellStyleAction, options, isUndo);
        }
        return false;
    }
};

export function initShortcutAboutStyle (commands: GC.Spread.Commands.CommandManager) {
    let isMac = Util._isMacOS(), ctrl = !isMac, meta = isMac;
    commands.register(SET_CELL_BOLD, Commands[SET_CELL_BOLD], 66 /* B */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(SET_CELL_ITALICIZE, Commands[SET_CELL_ITALICIZE], 73 /* I */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(SET_CELL_UNDERLINE, Commands[SET_CELL_UNDERLINE], 85 /* U */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(SET_NUMBER_TO_PERCENT, Commands[SET_NUMBER_TO_PERCENT], 53 /* % */, true /* ctrl */, true /* shift */, false /* alt */, false /* meta */);
}