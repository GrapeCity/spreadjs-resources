var path = require('path');

let webpackProductionConfig = {
    mode: 'production',
    output: {
        path: path.join(__dirname, './dist'),
        filename: 'spreadjs.globalization.min.js',
        libraryExport: "default",
        library: ['cultureInfos'],
        libraryTarget: 'umd'
    },
    entry: path.resolve(__dirname, './src/core.ts'),
    module: {
        rules: [
            {
                test: /\.ts$/,
                exclude: /node_modules/,
                loader: 'ts-loader',
            }
        ]
    },
    resolve: {
        extensions: ['.ts']
    },
    externals:{
        '@grapecity/spread-sheets':{
            root: "GC",
            commonjs: "@grapecity/spread-sheets",
            commonjs2: "@grapecity/spread-sheets",
            amd: "@grapecity/spread-sheets",
        }
    }
}

module.exports=webpackProductionConfig