import { Commands, executeCommand, IShortcutActionOptionBase, ShortcutActionBase } from "../shell/action.base";
import * as GC from "@grapecity/spread-sheets";
import { Util } from "../common/util";
const SET_DATE = 'setDate',
    COPY_CELL_DOWN = 'copyCellDown',
    COPY_CELL_RIGHT = 'copyCellRight';
const VerticalPosition = GC.Spread.Sheets.VerticalPosition;
const HorizontalPosition = GC.Spread.Sheets.HorizontalPosition;

interface ISetDateActionOption extends IShortcutActionOptionBase {
    date?: Date;
}

interface IAutoFillByDirectionActionOptions extends IShortcutActionOptionBase {
    direction?: GC.Spread.Sheets.Fill.FillDirection;
}

class SetDateUndoAction extends ShortcutActionBase<ISetDateActionOption> {
    canExecute (): boolean {
        return super._canEditInActiveCell();
    }
    executeImp (): boolean {
        let self = this;
        let sheet = self.getSheet();
        let options = self._options;
        sheet.suspendPaint();
        let activeRow = options.activeRowIndex as number, activeCol = options.activeColIndex as number;
        let date = options.date;
        sheet.startEdit();
        let cellType = sheet.getCellType(activeRow, activeCol);
        if (cellType && cellType.setEditorValue) {
            let editorElement = (cellType as any).getEditingElement();
            cellType.setEditorValue(editorElement, date ?.toLocaleDateString());
            cellType.focus(editorElement);
        }

        sheet.showCell(activeRow, activeCol, VerticalPosition.nearest, HorizontalPosition.nearest);
        sheet.resumePaint();
        return true;
    }
    canUndo () {
        return true;
    }
}

Commands[SET_DATE] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, option: ISetDateActionOption, isUndo: boolean) {
        let sheet = Util.getSheet(context, option);
        if (!isUndo && !option.cmd) {
            option.cmd = SET_DATE;
            let activeRowIndex = option.activeRowIndex ?? sheet.getActiveRowIndex();
            let activeColIndex = option.activeColIndex ?? sheet.getActiveColumnIndex();
            let date = new Date();
            date.setHours(0, 0, 0, 0);
            let value = sheet.getValue(activeRowIndex, activeColIndex);
            if (value instanceof Date) {
                if (value.getTime() === date.getTime()) {
                    return false;
                }
            }
            option.date = date;
        }
        return executeCommand(context, SetDateUndoAction, option, isUndo);
    }
};

class AutoFillDirectionAction extends ShortcutActionBase<IAutoFillByDirectionActionOptions> {
    executeImp () {
        let self = this;
        let sheet = self.getSheet();
        let selections = self._options.selections;
        let options = self._options as IAutoFillByDirectionActionOptions;
        if (selections.length === 1) { // In excel, only work for single selection range.
            let selection = selections[0], selectRowIndex = selection.row, selectColIndex = selection.col;
            if (options.direction === GC.Spread.Sheets.Fill.FillDirection.right && selection.colCount === 1) {
                let currentRange = selection;
                if (currentRange.col === 0) {
                    return true;
                }
                let table = sheet.tables.find(currentRange.row, currentRange.col - 1);
                if (table) { // left cell has table
                    let leftCellValue = Util.isRangeHasValue(sheet, new GC.Spread.Sheets.Range(currentRange.row, currentRange.col - 1, currentRange.rowCount, 1));
                    if (!leftCellValue) { // left cell no value, return directly.
                        return true;
                    }
                    // left cell has value and in table, if current cell not in table, need expand table col.
                    if (!table.range().intersect(currentRange.row, currentRange.col, 1, 1)) {
                        table.insertColumns(table.dataRange().colCount - 1, 1, true);
                    }
                    if (selection.rowCount > 1 && currentRange.row === table.range().row) {
                        sheet.copyTo(currentRange.row + 1, currentRange.col - 1, currentRange.row + 1, currentRange.col, currentRange.rowCount - 1, 1, GC.Spread.Sheets.CopyToOptions.value);
                    } else {
                        sheet.copyTo(currentRange.row, currentRange.col - 1, currentRange.row, currentRange.col, currentRange.rowCount, 1, GC.Spread.Sheets.CopyToOptions.value);
                    }
                    return true;
                }
                sheet.copyTo(currentRange.row, currentRange.col - 1, currentRange.row, currentRange.col, currentRange.rowCount, 1, GC.Spread.Sheets.CopyToOptions.all);
                return true;
            } else if (options.direction === GC.Spread.Sheets.Fill.FillDirection.down && selection.rowCount === 1) {
                let currentRange = selection;
                if (currentRange.row === 0) {
                    return true;
                }
                let table = sheet.tables.find(currentRange.row - 1, currentRange.col);
                if (table) { // up cell has table
                    // whether up cell has value or not, if current cell not in table, need expand table col.
                    if (!table.range().intersect(currentRange.row, currentRange.col, 1, 1)) {
                        table.insertRows(table.dataRange().rowCount - 1, 1, true);
                    }
                    sheet.copyTo(currentRange.row - 1, currentRange.col, currentRange.row, currentRange.col, 1, currentRange.colCount, GC.Spread.Sheets.CopyToOptions.value);
                    return true;
                }
                sheet.copyTo(currentRange.row - 1, currentRange.col, currentRange.row, currentRange.col, 1, currentRange.colCount, GC.Spread.Sheets.CopyToOptions.all);
                return true;
            }
            // include single cell and single range, cannot use setValue, as need copy formula too.
            let startRange: GC.Spread.Sheets.Range | null = null, fillRange;
            switch (options.direction) {
                case GC.Spread.Sheets.Fill.FillDirection.down:
                    if (selectRowIndex > 0) { // first row, skip
                        startRange = new GC.Spread.Sheets.Range(selectRowIndex, selectColIndex, 1, selection.colCount);
                        fillRange = new GC.Spread.Sheets.Range(selectRowIndex, selectColIndex, selection.rowCount, selection.colCount);
                    }
                    break;
                case GC.Spread.Sheets.Fill.FillDirection.right:
                    if (selectColIndex > 0) { // first col, skip
                        startRange = new GC.Spread.Sheets.Range(selectRowIndex, selectColIndex, selection.rowCount, 1);
                        fillRange = new GC.Spread.Sheets.Range(selectRowIndex, selectColIndex, selection.rowCount, selection.colCount);
                    }
                    break;
            }
            if (startRange && fillRange) {
                try {
                    sheet.fillAuto(startRange, fillRange, { fillType: GC.Spread.Sheets.Fill.FillType.direction, direction: options.direction } as GC.Spread.Sheets.Fill.IFillOptions);
                } catch (error) {
                }
                sheet.showCell(startRange.row, startRange.col, VerticalPosition.nearest, HorizontalPosition.nearest);
            }
        }
        return true;
    }
}

Commands[COPY_CELL_DOWN] = {
    canUndo: true,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IAutoFillByDirectionActionOptions, isUndo: boolean) {
        options.cmd = COPY_CELL_DOWN;
        let sheet = Util.getSheet(context, options);
        if ((sheet as any).isActualProtected()) {
            return true;
        }
        let selections = options.selections || sheet.getSelections();
        if (selections.length > 0) {
            options.direction = GC.Spread.Sheets.Fill.FillDirection.down;
            return executeCommand(context, AutoFillDirectionAction, options, isUndo);
        }
        return true;
    }
};

Commands[COPY_CELL_RIGHT] = {
    canUndo: true,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IAutoFillByDirectionActionOptions, isUndo: boolean) {
        options.cmd = COPY_CELL_RIGHT;
        let sheet = Util.getSheet(context, options);
        if ((sheet as any).isActualProtected()) {
            // ctrl + r refreshes the browser
            // return true to stops the event from bubbling.
            return true;
        }
        if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
            return true;
        }
        let selections = options.selections || sheet.getSelections();
        if (selections.length > 0) {
            options.direction = GC.Spread.Sheets.Fill.FillDirection.right;
            return executeCommand(context, AutoFillDirectionAction, options, isUndo);
        }
        return true;
    }
};

export function initShortcutAboutCell (commands: GC.Spread.Commands.CommandManager) {
    let isMac = Util._isMacOS(), ctrl = !isMac, meta = isMac;
    if (Util.isFirefox()) {
        commands.register(SET_DATE, Commands[SET_DATE], 59 /* semicolon */, ctrl, false /* shift */, false /* alt */, meta);
    } else {
        commands.register(SET_DATE, Commands[SET_DATE], 186 /* semicolon */, ctrl, false /* shift */, false /* alt */, meta);
    }
    commands.register(COPY_CELL_DOWN, Commands[COPY_CELL_DOWN], 68 /* D */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(COPY_CELL_RIGHT, Commands[COPY_CELL_RIGHT], 82 /* R */, ctrl, false /* shift */, false /* alt */, meta);
}