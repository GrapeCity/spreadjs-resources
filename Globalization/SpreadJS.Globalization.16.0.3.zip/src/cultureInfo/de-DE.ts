import * as GC from "@grapecity/spread-sheets";
let cultureInfo = new GC.Spread.Common.CultureInfo();
cultureInfo.id = 1031;
cultureInfo.displayName = "German (Germany)";
cultureInfo.name = function () { return "de-DE"; };
cultureInfo.NumberFormat.currencyDecimalSeparator = ",";
cultureInfo.NumberFormat.currencyGroupSeparator = ".";
cultureInfo.NumberFormat.currencySymbol = "€";
cultureInfo.NumberFormat.numberDecimalSeparator = ",";
cultureInfo.NumberFormat.numberGroupSeparator = ".";
cultureInfo.NumberFormat.listSeparator = ";";
cultureInfo.NumberFormat.arrayListSeparator = "\\";
cultureInfo.NumberFormat.arrayGroupSeparator = ";";
cultureInfo.DateTimeFormat.abbreviatedDayNames = ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"];
cultureInfo.DateTimeFormat.abbreviatedMonthGenitiveNames = ["Jan.", "Feb.", "März", "Apr.", "Mai", "Juni", "Juli", "Aug.", "Sept.", "Okt.", "Nov.", "Dez.", ""];
cultureInfo.DateTimeFormat.abbreviatedMonthNames = ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez", ""];
cultureInfo.DateTimeFormat.amDesignator = "AM";
cultureInfo.DateTimeFormat.dayNames = ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"];
cultureInfo.DateTimeFormat.fullDateTimePattern = "dddd, d. MMMM yyyy HH:mm:ss";
cultureInfo.DateTimeFormat.longDatePattern = "dddd, d. MMMM yyyy";
cultureInfo.DateTimeFormat.longTimePattern = "HH:mm:ss";
cultureInfo.DateTimeFormat.monthDayPattern = "d. MMMM";
cultureInfo.DateTimeFormat.monthGenitiveNames = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember", ""];
cultureInfo.DateTimeFormat.monthNames = ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember", ""];
cultureInfo.DateTimeFormat.pmDesignator = "PM";
cultureInfo.DateTimeFormat.shortDatePattern = "dd.MM.yyyy";
cultureInfo.DateTimeFormat.shortTimePattern = "HH:mm";
cultureInfo.DateTimeFormat.yearMonthPattern = "MMMM yyyy";
cultureInfo.predefinedFormats = {
    Accounting: '_-* #,##0.00 [$€-407]_-;-* #,##0.00 [$€-407]_-;_-* "-"?? [$€-407]_-;_-@_-',
    Currency: [
        "#,##0 [$€-407]",
        "#,##0 [$€-407];[Red]#,##0 [$€-407]",
        "#,##0 [$€-407];-#,##0 [$€-407]",
        "#,##0 [$€-407];[Red]-#,##0 [$€-407]"
    ],
    Date: [
        "yyyy-mm-dd;@",
        "d.m;@",
        "d.m.yy;@",
        "dd.mm.yy;@",
        "[$-407]d. mmm.;@",
        "[$-407]d. mmm. yy;@",
        "[$-407]d. mmm yy;@",
        "[$-407]mmm. yy;@",
        "[$-407]mmmm yy;@",
        "[$-407]d. mmm yy;@",
        "[$-409]d/m/yy h:mm AM/PM;@",
        "d.m.yy h:mm;@",
        "[$-407]mmmmm;@",
        "[$-407]mmmmm yy;@",
        "d.m.yyyy;@",
        "[$-407]d. mmm. yyyy;@"
    ],
    Time: [
        "h:mm;@",
        "[$-409]h:mm AM/PM;@",
        "h:mm:ss;@",
        "[$-409]h:mm:ss AM/PM;@",
        "mm:ss.0;@",
        "[h]:mm:ss;@",
        "[$-409]d/m/yy h:mm AM/PM;@",
        "d.m.yy h:mm;@"
    ],
    Special: {
        "Postleitzahl": "00000",
        "Postleitzahl (A)": "A-00000",
        "Postleitzahl (CH)": "CH-00000",
        "Postleitzahl (D)": "D-00000",
        "Postleitzahl (L)": "L-00000",
        "Versicherungsnachweis-Nr. (D)": "[@]",
        "Sozialversicherungsnummer (A)": "0000-00 00 00",
        "Sozialversicherungsnummer (CH)": "000.00.000.000",
        "ISBN-Format (ISBN x-xxx-xxxxx-x)": "ISBN #-###-#####-#",
        "ISBN-Format (ISBN x-xxxx-xxxx-x)": "ISBN #-####-####-#",
        "ISBN-Format (ISBN x-xxxxx-xxx-x)": "ISBN #-#####-###-#"
    }
};
export default cultureInfo;
