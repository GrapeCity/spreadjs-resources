import { Commands, IShortcutActionOptionBase } from "../shell/action.base";
import * as GC from "@grapecity/spread-sheets";
import { Util } from "../common/util";
const SELECT_ENTIRE_ROW = 'selectEntireRow',
    GO_SHEET_BEGINNING = 'goToSheetBeginning',
    SELECT_ENTIRE_COLUMN = 'selectEntireColumn',
    GO_SHEET_BOTTOM_RIGHT = 'goToSheetBottomRight',
    GO_TO_PRECEDENTS = 'goToPrecedent',
    SELECT_VISIBLE_CELLS = 'selectVisibleCells',
    GO_TO_DEPENDENTS = 'goToDependents',
    SELECT_ALL = 'SelectAll';


const VerticalPosition = GC.Spread.Sheets.VerticalPosition;
const HorizontalPosition = GC.Spread.Sheets.HorizontalPosition;

Commands[SELECT_ENTIRE_ROW] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase) {
        let sheet = context.getSheetFromName(options.sheetName);
        options.cmd = SELECT_ENTIRE_ROW;
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            let selections = sheet.getSelections();
            sheet.suspendPaint();
            sheet.clearSelection();
            if (selections.length === 1) {
                let selection = selections[0];
                sheet.setSelection(selection.row, -1, selection.rowCount, sheet.getColumnCount());
            } else {
                for (let i = 0; i < selections.length; i++) {
                    let selection = selections[i];
                    sheet.addSelection(selection.row, -1, selection.rowCount, sheet.getColumnCount());
                }
            }
            sheet.resumePaint();
            return true;
        }
        return false;
    }
};

Commands[SELECT_ENTIRE_COLUMN] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase) {
        let sheet = context.getSheetFromName(options.sheetName);
        options.cmd = SELECT_ENTIRE_COLUMN;
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            let selections = sheet.getSelections();
            sheet.suspendPaint();
            sheet.clearSelection();
            if (selections.length === 1) {
                let selection = selections[0];
                sheet.setSelection(-1, selection.col, sheet.getRowCount(), selection.colCount);
            } else {
                for (let i = 0; i < selections.length; i++) {
                    let selection = selections[i];
                    sheet.addSelection(-1, selection.col, sheet.getRowCount(), selection.colCount);
                }
            }
            sheet.resumePaint();
            return true;
        }
        return false;
    }
};

Commands[GO_SHEET_BEGINNING] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase) {
        let sheet = context.getSheetFromName(options.sheetName);
        options.cmd = GO_SHEET_BEGINNING;
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            sheet.suspendPaint();
            sheet.showCell(0, 0, GC.Spread.Sheets.VerticalPosition.nearest, GC.Spread.Sheets.HorizontalPosition.nearest);
            sheet.setSelection(0, 0, 1, 1);
            sheet.resumePaint();
            return true;
        }
        return false;
    }
};

Commands[GO_SHEET_BOTTOM_RIGHT] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase) {
        let sheet = context.getSheetFromName(options.sheetName);
        options.cmd = GO_SHEET_BOTTOM_RIGHT;
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            let lastNonNullRow = (sheet as any).getLastNonNullRow();
            let lastNonNullCol = (sheet as any).getLastNonNullColumn();
            sheet.showCell(lastNonNullRow, lastNonNullCol, VerticalPosition.nearest, HorizontalPosition.nearest);
            sheet.setSelection(lastNonNullRow, lastNonNullCol, 1, 1);
            return true;
        }
        return false;
    }
};

function getPrecedentsOrDependentsFromSelections (sheet: GC.Spread.Sheets.Worksheet, isPrecedents: boolean): GC.Spread.Sheets.ICellsInfo[] {
    let selections = sheet.getSelections();
    let result: GC.Spread.Sheets.ICellsInfo[] = [];
    selections.forEach((selection) => {
        let row = selection.row, col = selection.col;
        let rowCount = selection.rowCount, colCount = selection.colCount;
        for (let i = row; i < row + rowCount; i++) {
            for (let j = col; j < col + colCount; j++) {
                if (isPrecedents) {
                    result = result.concat(sheet.getPrecedents(i, j));
                } else {
                    result = result.concat(sheet.getDependents(i, j));
                }
            }
        }
    });
    return result;
}

function isRangeAdjacentOrIntersect (range: GC.Spread.Sheets.ICellsInfo, compareRange: GC.Spread.Sheets.ICellsInfo, isRow: boolean): boolean {
    if (isRow) {
        if (range.row === compareRange.row && range.rowCount === compareRange.rowCount) {
            let [leftRange, rightRange] = range.col < compareRange.col ? [range, compareRange] : [compareRange, range];
            let maxColIndex = leftRange.col + leftRange.colCount, minColIndex = leftRange.col;
            if (rightRange.col >= minColIndex && rightRange.col <= maxColIndex) {
                return true;
            } else {
                return false;
            }
        }
    } else {
        if (range.col === compareRange.col && range.colCount === compareRange.colCount) {
            let [topRange, bottomRange] = range.row < compareRange.row ? [range, compareRange] : [compareRange, range];
            let maxRowIndex = topRange.row + topRange.rowCount, minRowIndex = topRange.row;
            if (bottomRange.row >= minRowIndex && bottomRange.row <= maxRowIndex) {
                return true;
            } else {
                return false;
            }
        }
    }
    return false;
}


function getRangeAfterMerge (ranges: GC.Spread.Sheets.ICellsInfo[]): GC.Spread.Sheets.ICellsInfo[] {
    let len = ranges.length;
    if (len === 1) {
        return ranges;
    } else if (len === 0) {
        return [];
    } else {
        for (let i = 0; i < len; i++) {
            for (let j = i + 1; j < len; j++) {
                let range = ranges[i], compareRange = ranges[j];
                if (!compareRange || range.sheetName !== compareRange.sheetName) {
                    break;
                } else {
                    if (isRangeAdjacentOrIntersect(range, compareRange, true)) {
                        let col = Math.min(range.col, compareRange.col);
                        let endColAfterMerge = Math.max(range.col + range.colCount, compareRange.col + compareRange.colCount);
                        let colCount = endColAfterMerge - col;
                        let newRange: GC.Spread.Sheets.ICellsInfo = {
                            sheetName: range.sheetName,
                            row: range.row,
                            rowCount: range.rowCount,
                            col: col,
                            colCount: colCount
                        };
                        ranges.splice(j, 1);
                        ranges.splice(i, 1, newRange);
                        break;
                    } else if (isRangeAdjacentOrIntersect(range, compareRange, false)) {
                        let row = Math.min(range.row, compareRange.row);
                        let endRowAfterMerge = Math.max(range.row + range.rowCount, compareRange.row + compareRange.rowCount);
                        let rowCount = endRowAfterMerge - row;
                        let newRange: GC.Spread.Sheets.ICellsInfo = {
                            sheetName: range.sheetName,
                            row: row,
                            rowCount: rowCount,
                            col: range.col,
                            colCount: range.colCount
                        };
                        ranges.splice(j, 1);
                        ranges.splice(i, 1, newRange);
                        break;
                    }
                }
            }
        }
    }
    if (ranges.length === len) {
        return ranges;
    } else {
        return getRangeAfterMerge(ranges);
    }
}

Commands[GO_TO_DEPENDENTS] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: any, isUndo) {
        let sheet = context.getSheetFromName(options.sheetName);
        let dependents = getPrecedentsOrDependentsFromSelections(sheet, false);
        if (dependents.length > 0 && sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            sheet.suspendPaint();
            sheet.clearSelection();
            dependents = getRangeAfterMerge(dependents);
            for (let i = 0; i < dependents.length; i++) {
                let cellInfo = dependents[i];
                if (i === 0) {
                    sheet.showCell(cellInfo.row, cellInfo.col, VerticalPosition.nearest, HorizontalPosition.nearest);
                    sheet.setSelection(cellInfo.row, cellInfo.col, cellInfo.rowCount, cellInfo.colCount);
                } else {
                    sheet.addSelection(cellInfo.row, cellInfo.col, cellInfo.rowCount, cellInfo.colCount);
                }
            }
            sheet.resumePaint();
            return true;
        }
        return false;
    }
};

Commands[GO_TO_PRECEDENTS] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: any, isUndo) {
        let sheet = context.getSheetFromName(options.sheetName);
        let precedents = getPrecedentsOrDependentsFromSelections(sheet, true);
        if (precedents.length > 0 && sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            sheet.suspendPaint();
            sheet.clearSelection();
            precedents = getRangeAfterMerge(precedents);
            for (let i = 0; i < precedents.length; i++) {
                let cellInfo = precedents[i];
                if (i === 0) {
                    sheet.showCell(cellInfo.row, cellInfo.col, VerticalPosition.nearest, HorizontalPosition.nearest);
                    sheet.setSelection(cellInfo.row, cellInfo.col, cellInfo.rowCount, cellInfo.colCount);
                } else {
                    sheet.addSelection(cellInfo.row, cellInfo.col, cellInfo.rowCount, cellInfo.colCount);
                }
            }
            sheet.resumePaint();
            return true;
        }
        return false;
    }
};

Commands[SELECT_VISIBLE_CELLS] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = context.getSheetFromName(options.sheetName);
        options.cmd = SELECT_VISIBLE_CELLS;
        let visibleRanges = Util.getInvisibleRange(sheet);
        if (visibleRanges.length > 0 && sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            sheet.suspendPaint();
            sheet.clearSelection();
            visibleRanges.forEach((visibleRange) => {
                sheet.addSelection(visibleRange.row, visibleRange.col, visibleRange.rowCount, visibleRange.colCount);
            });
            sheet.resumePaint();
        }
        return true;
    }
};

Commands[SELECT_ALL] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = context.getSheetFromName(options.sheetName);
        options.cmd = SELECT_ALL;
        let rowCount = sheet.getRowCount(), colCount = sheet.getColumnCount();
        sheet.suspendPaint();
        sheet.clearSelection();
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            sheet.setSelection(-1, -1, rowCount, colCount);
        }
        sheet.resumePaint();
        return true;
    }
};

export function initShortcutAboutSelection (commands: GC.Spread.Commands.CommandManager) {
    commands.register(SELECT_ENTIRE_ROW, Commands[SELECT_ENTIRE_ROW], 32 /* SPACE*/, false, true, false, false);
    commands.register(SELECT_ENTIRE_COLUMN, Commands[SELECT_ENTIRE_COLUMN], 32 /* SPACE */, true, false, false, false);
    commands.register(GO_SHEET_BEGINNING, Commands[GO_SHEET_BEGINNING], 36 /* HOME */, true, false, false, false);
    commands.register(GO_SHEET_BOTTOM_RIGHT, Commands[GO_SHEET_BOTTOM_RIGHT], 35 /* END */, true, false, false, false);
    commands.register(GO_TO_DEPENDENTS, Commands[GO_TO_DEPENDENTS], 221 /* ] */, true, false, false, false);
    commands.register(GO_TO_PRECEDENTS, Commands[GO_TO_PRECEDENTS], 219 /* [ */, true, false, false, false);
    commands.register(SELECT_ALL, Commands[SELECT_ALL], 65 /* A */, true, false, false, false);
    if (Util.isFirefox()) {
        commands.register(SELECT_VISIBLE_CELLS, Commands[SELECT_VISIBLE_CELLS], 59 /* semicolon */, false, false, true, false);
    } else {
        commands.register(SELECT_VISIBLE_CELLS, Commands[SELECT_VISIBLE_CELLS], 186 /* semicolon */, false, false, true, false);
    }
}