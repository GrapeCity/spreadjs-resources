const fs = require('fs');
const path = require('path');
var glob = require('glob');


function makeSureDirectoryExists(src) {
    var oPath = path.parse(src), dir = oPath.dir,
        parents = [];
    while (!fs.existsSync(dir)) {
        parents.push(dir);
        dir = path.parse(dir).dir;
    }

    while (parents.length > 0) {
        var dest = parents.pop();
        fs.mkdirSync(dest);
    }
}
function copyOneFile(src, dest) {
    // console.log(src, dest);
    makeSureDirectoryExists(dest);
    fs.writeFileSync(dest, fs.readFileSync(src));
}
function copyRecursiveSync(src, dest) {
    var exists = fs.existsSync(src);
    var stats = exists && fs.statSync(src);
    var isDirectory = exists && stats.isDirectory();
    if (exists && isDirectory) {
        fs.readdirSync(src).forEach(function (childItemName) {
            copyRecursiveSync(path.join(src, childItemName), path.join(dest, childItemName));
        });
    } else {
        copyOneFile(src, dest);
    }
}

function deleteFolderRecursive(path, nameContains) {
    var files = [];
    if (fs.existsSync(path)) {
        files = fs.readdirSync(path);
        files.forEach(function (file, index) {
            var curPath = path + "/" + file;
            if (fs.lstatSync(curPath).isDirectory()) { // recurse
                deleteFolderRecursive(curPath, nameContains);
            } else { // delete file
                if (!nameContains || file.indexOf(nameContains) >= 0) {
                    fs.unlinkSync(curPath);
                }
            }
        });
        //fs.rmdirSync(path);
    }
}

function deleteFolderRecursiveWithItSelf(path) {
    if( fs.existsSync(path) ) {
        fs.readdirSync(path).forEach(function(file,index){
            var curPath = path + "/" + file;
            if(fs.lstatSync(curPath).isDirectory()) { // recurse
                deleteFolderRecursiveWithItSelf(curPath);
            } else { // delete file
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(path);
    }
};

/**
 * Copy all the files.
 * @param srcPath It's a path with the pattern shell uses. Like this: C:/text/*.js or C:/main/** /*.js
 * @param destPath
 * @param fileNameFunc It's a call back for rename
 */
function copyFiles(srcPath, destPath, fileNameFunc) {
    // Like this: C:/text/*.js or C:/main/**/*.js
    var asteriskPosition = srcPath.indexOf('*');
    var mainPath = '';
    if (asteriskPosition > -1) {
        // here find the first *, as the main folder, copy all the file in current folder and subfolder.
        mainPath = srcPath.substring(0, srcPath.lastIndexOf('/', asteriskPosition) + 1)
    } else {
        mainPath = srcPath.substring(0, srcPath.lastIndexOf('/') + 1);
    }
    var files = glob.sync(srcPath);

    if (files && files.length > 0) {
        files.forEach(function (filepath) {
            if (fs.lstatSync(filepath).isFile()) {
                // here replace the main folder, keep the subfolder structure in destPath
                var filename = filepath.replace(mainPath, '');
                var destFile = path.resolve(destPath, filename);
                if (fileNameFunc) {
                    destFile = fileNameFunc(destFile);
                }
                copyOneFile(filepath, destFile);
            }
        })
    }
}

/**
 * Delete all the files.
 * @param path It's a path with the pattern shell uses. Like this: C:/text/*.js or C:/main/** /*.js
 */
function deleteFiles(path) {
    // Like this: C:/text/*.js or C:/main/**/*.js
    var files = glob.sync(path);
    if (files && files.length > 0) {
        files.forEach(function (filepath) {
            if (fs.lstatSync(filepath).isFile()) {
                fs.unlinkSync(filepath);
            }
        })
    }
}


/**
 * Delete the folder
 * @param path It's a path with the pattern shell uses, such as removeFolder(path.resolve('../Build/output/scripts'));
 */
function removeFolder(pathTemp) {
    deleteFolderRecursiveWithItSelf(pathTemp);
}

/**
 * copy the folder
  */
function copyFolder(srcFolder, destFolder) {
    // clear destFolder
    deleteFolderRecursive(destFolder);
    // copy srcFolder to destFolder
    copyRecursiveSync(srcFolder, destFolder);
}


exports.copyOneFile = copyOneFile;
exports.copyFiles = copyFiles;
exports.deleteFiles = deleteFiles;
exports.copyRecursiveSync = copyRecursiveSync;
exports.deleteFolderRecursive = deleteFolderRecursive;
exports.removeFolder = removeFolder;
exports.copyFolder = copyFolder;