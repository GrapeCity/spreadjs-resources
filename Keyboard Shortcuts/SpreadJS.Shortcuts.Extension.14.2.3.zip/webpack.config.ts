var path = require('path');


let shortcutConfig = {
    mode: 'development',
    devtool: 'source-map',
    output: {
        path: path.join(__dirname, './dist'),
        filename: './spreadjs_shortcut_command.js',
        devtoolModuleFilenameTemplate: '[absolute-resource-path]',
        library: ['Shortcut'],
        libraryTarget: 'umd'
    },
    entry: path.resolve(__dirname, './src/entry.ts'),
    module: {
        rules: [
            {
                test: /\.ts$/,
                use: ['ts-loader'],
                exclude: '/node_modules/'
            }
        ]
    },
    resolve: {
        extensions: ['.ts']
    },
    externals:{
        '@grapecity/spread-sheets':"GC"
    }
}

export = [
    shortcutConfig
]
