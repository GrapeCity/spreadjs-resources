import GC = require("@grapecity/spread-sheets");
import { initShortcutAboutCalc } from "./shortcut/action.calc";
import { initShortcutAboutCell } from "./shortcut/action.cell";
import { initShortcutAboutRowsAndColumns } from "./shortcut/action.row.column";
import { initShortcutAboutSelection } from "./shortcut/action.selection";
import { initShortcutAboutStyle } from "./shortcut/action.style";

export function addSpreadShortcut (spread: GC.Spread.Sheets.Workbook) {
    let commandManager = spread.commandManager();
    if (!commandManager) {
        return;
    }
    initShortcutAboutRowsAndColumns(commandManager);
    initShortcutAboutSelection(commandManager);
    initShortcutAboutCalc(commandManager);
    initShortcutAboutCell(commandManager);
    initShortcutAboutStyle(commandManager);
}
