import { Commands, IShortcutActionOptionBase } from "../shell/action.base";
import * as GC from "@grapecity/spread-sheets";
import { Util, ActiveCellPositionInRange } from "../common/util";

const SELECT_ENTIRE_ROW = 'selectEntireRow',
    GO_SHEET_BEGINNING = 'goToSheetBeginning',
    SELECT_ENTIRE_COLUMN = 'selectEntireColumn',
    GO_SHEET_BOTTOM_RIGHT = 'goToSheetBottomRight',
    GO_TO_PRECEDENTS = 'goToPrecedent',
    SELECT_VISIBLE_CELLS = 'selectVisibleCells',
    GO_TO_DEPENDENTS = 'goToDependents',
    SELECT_ALL = 'SelectAll',
    SELECTION_HOME = 'selectionHome',
    SELECTION_END = 'selectionEnd',
    SELECTION_TOP = 'selectionTop',
    SELECTION_BOTTOM = 'selectionBottom',
    GOTO_NEXT_TOP_NON_NULL_CELL = 'gotoNextTopNonNullCell',
    GOTO_NEXT_BOTTOM_NON_NULL_CELL = 'gotoNextBottomNonNullCell',
    GOTO_NEXT_LEFT_NON_NULL_CELL = 'gotoNextLeftNonNullCell',
    GOTO_NEXT_RIGHT_NON_NULL_CELL = 'gotoNextRightNonNullCell';

const VerticalPosition = GC.Spread.Sheets.VerticalPosition;
const HorizontalPosition = GC.Spread.Sheets.HorizontalPosition;

Commands[SELECT_ENTIRE_ROW] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase) {
        let sheet = Util.getSheet(context, options);
        options.cmd = SELECT_ENTIRE_ROW;
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            let selections = sheet.getSelections(), lastSelctionIndex = selections.length - 1;
            // In excel, when multi range selected, only larger last range's entire row, keep other range selected.
            let lastSelection = selections[lastSelctionIndex];
            if (lastSelection) {
                lastSelection.col = -1;
                lastSelection.colCount = sheet.getColumnCount();
                sheet.repaint();
            }
            return true;
        }
        return false;
    }
};

Commands[SELECT_ENTIRE_COLUMN] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase) {
        let sheet = Util.getSheet(context, options);
        options.cmd = SELECT_ENTIRE_COLUMN;
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            let selections = sheet.getSelections(), lastSelctionIndex = selections.length - 1;
            // In excel, when multi range selected, only larger last range's entire column, keep other range selected.
            let lastSelection = selections[lastSelctionIndex];
            if (lastSelection) {
                lastSelection.row = -1;
                lastSelection.rowCount = sheet.getRowCount();
                sheet.repaint();
            }
            return true;
        }
        return false;
    }
};

Commands[GO_SHEET_BEGINNING] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase) {
        let sheet = Util.getSheet(context, options);
        options.cmd = GO_SHEET_BEGINNING;
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            sheet.suspendPaint();
            sheet.showCell(0, 0, GC.Spread.Sheets.VerticalPosition.nearest, GC.Spread.Sheets.HorizontalPosition.nearest);
            sheet.setSelection(0, 0, 1, 1);
            sheet.resumePaint();
            return true;
        }
        return false;
    }
};

Commands[GO_SHEET_BOTTOM_RIGHT] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase) {
        let sheet = Util.getSheet(context, options);
        options.cmd = GO_SHEET_BOTTOM_RIGHT;
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            let lastNonNullRow = (sheet as any).getLastNonNullRow();
            let lastNonNullCol = (sheet as any).getLastNonNullColumn();
            sheet.showCell(lastNonNullRow, lastNonNullCol, VerticalPosition.nearest, HorizontalPosition.nearest);
            sheet.setSelection(lastNonNullRow, lastNonNullCol, 1, 1);
            return true;
        }
        return false;
    }
};

function getPrecedentsOrDependentsFromSelections (sheet: GC.Spread.Sheets.Worksheet, isPrecedents: boolean, option: IShortcutActionOptionBase): GC.Spread.Sheets.ICellsInfo[] {
    let selections = option.selections || sheet.getSelections();
    let result: GC.Spread.Sheets.ICellsInfo[] = [];
    selections.forEach((selection: GC.Spread.Sheets.Range) => {
        let row = selection.row, col = selection.col;
        let rowCount = selection.rowCount, colCount = selection.colCount;
        if (rowCount === -1) {
            rowCount = 1;
        }
        if (colCount === -1) {
            colCount = 1;
        }
        for (let i = row; i < row + rowCount; i++) {
            for (let j = col; j < col + colCount; j++) {
                if (isPrecedents) {
                    result = result.concat(sheet.getPrecedents(i, j));
                } else {
                    result = result.concat(sheet.getDependents(i, j));
                }
            }
        }
    });
    return result;
}

function isRangeAdjacentOrIntersect (range: GC.Spread.Sheets.ICellsInfo, compareRange: GC.Spread.Sheets.ICellsInfo, isRow: boolean): boolean {
    if (isRow) {
        if (range.row === compareRange.row && range.rowCount === compareRange.rowCount) {
            let [leftRange, rightRange] = range.col < compareRange.col ? [range, compareRange] : [compareRange, range];
            let maxColIndex = leftRange.col + (leftRange.colCount ?? 1), minColIndex = leftRange.col;
            if (rightRange.col >= minColIndex && rightRange.col <= maxColIndex) {
                return true;
            } else {
                return false;
            }
        }
    } else {
        if (range.col === compareRange.col && range.colCount === compareRange.colCount) {
            let [topRange, bottomRange] = range.row < compareRange.row ? [range, compareRange] : [compareRange, range];
            let maxRowIndex = topRange.row + (topRange.rowCount ?? 1), minRowIndex = topRange.row;
            if (bottomRange.row >= minRowIndex && bottomRange.row <= maxRowIndex) {
                return true;
            } else {
                return false;
            }
        }
    }
    return false;
}

function getRangeAfterMerge (ranges: GC.Spread.Sheets.ICellsInfo[]): GC.Spread.Sheets.ICellsInfo[] {
    let len = ranges.length;
    if (len === 1) {
        return ranges;
    } else if (len === 0) {
        return [];
    } else {
        for (let i = 0; i < len; i++) {
            for (let j = i + 1; j < len; j++) {
                let range = ranges[i], compareRange = ranges[j];
                if (!compareRange || range.sheetName !== compareRange.sheetName) {
                    break;
                } else {
                    if (isRangeAdjacentOrIntersect(range, compareRange, true)) {
                        let col = Math.min(range.col, compareRange.col);
                        let endColAfterMerge = Math.max(range.col + (range.colCount ?? 1), compareRange.col + (compareRange.colCount ?? 1));
                        let colCount = endColAfterMerge - col;
                        let newRange: GC.Spread.Sheets.ICellsInfo = {
                            sheetName: range.sheetName,
                            row: range.row,
                            rowCount: range.rowCount,
                            col: col,
                            colCount: colCount
                        };
                        ranges.splice(j, 1);
                        ranges.splice(i, 1, newRange);
                        break;
                    } else if (isRangeAdjacentOrIntersect(range, compareRange, false)) {
                        let row = Math.min(range.row, compareRange.row);
                        let endRowAfterMerge = Math.max(range.row + (range.rowCount ?? 1), compareRange.row + (compareRange.rowCount ?? 1));
                        let rowCount = endRowAfterMerge - row;
                        let newRange: GC.Spread.Sheets.ICellsInfo = {
                            sheetName: range.sheetName,
                            row: row,
                            rowCount: rowCount,
                            col: range.col,
                            colCount: range.colCount
                        };
                        ranges.splice(j, 1);
                        ranges.splice(i, 1, newRange);
                        break;
                    }
                }
            }
        }
    }
    if (ranges.length === len) {
        return ranges;
    } else {
        return getRangeAfterMerge(ranges);
    }
}

function setSelectionForSheet (sheet: GC.Spread.Sheets.Worksheet, selectionInfos: any) {
    for (let i = 0; i < selectionInfos.length; i++) {
        let info = selectionInfos[i], row = info.row, col = info.col, rowCount = info.rowCount, colCount = info.colCount;
        if (i === 0) {
            if (rowCount === 1 && colCount === 1) {
                sheet.setActiveCell(row, col);
                sheet.showCell(row, col, VerticalPosition.nearest, HorizontalPosition.nearest);
            } else {
                sheet.setSelection(row, col, rowCount, colCount);
            }
        } else {
            sheet.addSelection(row, col, rowCount, colCount);
        }
    }
}

function handlePrecedentOrDependent (context: GC.Spread.Sheets.Workbook, option: IShortcutActionOptionBase, isPrecedent: boolean) {
    let currentSheetName = option.sheetName, sheet = Util.getSheet(context, option);
    if ((sheet as any).isActualProtected() && Util.containLockedCellsInSelections(sheet)) {
        let resources = (GC.Spread.Sheets as any).Designer.getResources();
        (GC.Spread.Sheets as any).Designer.showMessageBox(resources.isProtected, resources.title, (GC.Spread.Sheets as any).Designer.MessageBoxIcon.warning);
        return false;
    }
    let infos = getPrecedentsOrDependentsFromSelections(sheet, isPrecedent, option);
    infos.sort(function (a, b) {
        if (a.sheetName === currentSheetName && b.sheetName !== currentSheetName) {
            return -1;
        } else if (a.sheetName !== currentSheetName && b.sheetName === currentSheetName) {
            return 1;
        } else {
            return 0;
        }
    });
    if (infos.length > 0 && sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
        sheet.suspendPaint();
        infos = getRangeAfterMerge(infos);
        let toSheetName = currentSheetName, selectionInfos = [];
        for (let i = 0; i < infos.length; i++) {
            let info = infos[i], sheetName = info.sheetName;
            if (i === 0) {
                toSheetName = sheetName;
            } else if (sheetName !== toSheetName) {
                continue;
            }
            selectionInfos.push(info);
        }
        // Ref to the first reference's sheet.
        let toSheet = sheet;
        if (toSheetName !== currentSheetName) {
            toSheet = Util.getSheet(context, option);
            if (toSheet instanceof GC.Spread.Sheets.Worksheet) {
                context.setActiveSheet(toSheetName);
            } else if ((toSheet as GC.Spread.Report.ReportSheet) instanceof GC.Spread.Report.ReportSheet && (toSheet as GC.Spread.Report.ReportSheet).renderMode() === 'Design') {
                context.setActiveSheetTab(toSheetName);
            }
        }
        setSelectionForSheet(toSheet, selectionInfos);

        sheet.resumePaint();
        return true;
    }
    return false;
}

Commands[GO_TO_DEPENDENTS] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo) {
        return handlePrecedentOrDependent(context, options, false /* isPrecedent */);
    }
};

Commands[GO_TO_PRECEDENTS] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo) {
        return handlePrecedentOrDependent(context, options, true /* isPrecedent */);
    }
};

Commands[SELECT_VISIBLE_CELLS] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let getSheet = (): GC.Spread.Sheets.Worksheet => {
            let activeSheet = context.getSheetFromName(options.sheetName);
            if (activeSheet === undefined) {
                const sheetTab = context.getActiveSheetTab();
                if (sheetTab && typeof sheetTab.renderMode === 'function') {
                    return sheetTab.getTemplate();
                }
            }
            return activeSheet;
        };
        let sheet = getSheet();
        options.cmd = SELECT_VISIBLE_CELLS;
        let visibleRanges = Util.getInvisibleRange(sheet);
        if (visibleRanges.length > 0 && sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            sheet.suspendPaint();
            sheet.clearSelection();
            let firstVisibleRange = visibleRanges.shift() as GC.Spread.Sheets.Range;
            sheet.setSelection(firstVisibleRange.row, firstVisibleRange.col, firstVisibleRange.rowCount, firstVisibleRange.colCount);
            visibleRanges.forEach((visibleRange) => {
                sheet.addSelection(visibleRange.row, visibleRange.col, visibleRange.rowCount, visibleRange.colCount);
            });
            sheet.resumePaint();
        }
        return true;
    }
};

function isSelectedPivotTable (sheet: GC.Spread.Sheets.Worksheet, option: IShortcutActionOptionBase) {
    if (!sheet.pivotTables) {
        return false;
    }
    let selections = option.selections || sheet.getSelections();
    let pts = sheet.pivotTables.all();
    if (pts.length === 0) {
        return false;
    }
    for (let selectedRange of selections) {
        for (let i = 0; i < pts.length; i++) {
            let pt = pts[i];
            let { page, content } = pt.getRange();
            if (page && page.equals(selectedRange) || content && content.equals(selectedRange)) {
                return false;
            }
            if (page && page.containsRange(selectedRange) || content && content.containsRange(selectedRange)) {
                continue;
            } else {
                return false;
            }
        }
    }
    return true;
}

Commands[SELECT_ALL] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
            return false;
        }
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.enter || sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.edit) {
            return false;
        }
        if (isSelectedPivotTable(sheet, options)) {
            return false;
        }
        options.cmd = SELECT_ALL;
        let selections = options.selections || sheet.getSelections();
        let row = -1, col = -1, rowCount = sheet.getRowCount(), colCount = sheet.getColumnCount();
        let activeRow = options.activeRowIndex ?? sheet.getActiveRowIndex(), activeCol = options.activeColIndex ?? sheet.getActiveColumnIndex();
        let selection = Util.getNeedAdjustSelection(selections, activeRow, activeCol);
        if (!selection) {
            return false;
        }
        let targetRange;
            targetRange = (sheet as any).expandSelection(sheet, new GC.Spread.Sheets.Range(activeRow, activeCol, 1, 1));
            row = targetRange.row;
            col = targetRange.col;
            rowCount = targetRange.rowCount;
            colCount = targetRange.colCount;
        let table = sheet.tables.find(activeRow, activeCol);
        if (table) {
            targetRange = table.range();
            if (targetRange.rowCount > 1) {
                let selectedRange = Util.getActiveSelectedRange(selections, activeRow, activeCol);
                if (!selectedRange) {
                    return false;
                }
                let tableBodyRange = new GC.Spread.Sheets.Range(targetRange.row + 1, targetRange.col, targetRange.rowCount - 1, targetRange.colCount);

                if (selectedRange.equals(tableBodyRange) || selectedRange.intersect(targetRange.row, targetRange.col, 1, targetRange.colCount)) {
                    row = targetRange.row;
                    col = targetRange.col;
                    rowCount = targetRange.rowCount;
                    colCount = targetRange.colCount;
                } else {
                    row = tableBodyRange.row;
                    col = tableBodyRange.col;
                    rowCount = tableBodyRange.rowCount;
                    colCount = tableBodyRange.colCount;
                }
            }
        }
        for (let selectedRange of selections) {
            if (targetRange && targetRange.equals(selectedRange)) {
                row = -1;
                col = -1;
                rowCount = sheet.getRowCount();
                colCount = sheet.getColumnCount();
                break;
            }
        }
        if (sheet.editorStatus() === GC.Spread.Sheets.EditorStatus.ready) {
            sheet.suspendPaint();
            selection.row = row;
            selection.col = col;
            selection.rowCount = rowCount;
            selection.colCount = colCount;
            sheet.resumePaint();
            return true;
        }
        return false;
    }
};

function expand_Selection (sheet: GC.Spread.Sheets.Worksheet, currentRange: GC.Spread.Sheets.Range) {
    let spans = sheet.getSpans(currentRange);
    let newRange = currentRange;
    for (let span of spans) {
        newRange = newRange.union(span);
    }
    currentRange.row = newRange.row;
    currentRange.col = newRange.col;
    currentRange.rowCount = newRange.rowCount;
    currentRange.colCount = newRange.colCount;
}

function selectionHomeExecute (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
    let sheet = Util.getSheet(context, options);
    let selections = options.selections || sheet.getSelections(), activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(), activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
    if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
        return false;
    }
    if (sheet.editorStatus() !== 0) {
        return (sheet as any).changeFormulaTextCtrlShift(sheet, 3 /* left */);
    }
    let selNeedAdjust = Util.getNeedAdjustSelection(selections, activeRowIndex, activeColIndex);
    if (selNeedAdjust !== null) {
        let activePosition = Util.getCellPositionInRangeByCol(selNeedAdjust, activeColIndex);
        if (activePosition === ActiveCellPositionInRange.middle && selNeedAdjust.col === -1) {
            return true;
        }
        sheet.suspendPaint();
        let findResult, lastColIndex, nextVisibleColIndex;

        if (activePosition === ActiveCellPositionInRange.end) {
            lastColIndex = selNeedAdjust.col;
        } else if (activePosition === ActiveCellPositionInRange.start) {
            lastColIndex = selNeedAdjust.col + selNeedAdjust.colCount - 1;
        } else {
            lastColIndex = selNeedAdjust.col;
        }

        let startSearchIndex = activePosition === ActiveCellPositionInRange.start ? (selNeedAdjust.col + selNeedAdjust.colCount - 1 - 1) : (selNeedAdjust.col - 1);

        nextVisibleColIndex = lastColIndex - 1;
        while (nextVisibleColIndex >= 0 && !sheet.getColumnVisible(nextVisibleColIndex)) {
            nextVisibleColIndex--;
        }
        let LastCellNonNull = Util.hasValue(sheet, activeRowIndex, lastColIndex);
        let nextCellNonNull = Util.hasValue(sheet, activeRowIndex, nextVisibleColIndex);
        let acrossCellsBlock = LastCellNonNull && nextCellNonNull;

        if (acrossCellsBlock) {
            findResult = Util.findFirstNotNullColIndexInRange(sheet, activeRowIndex, startSearchIndex);
        } else {
            findResult = Util.findPreviousNotNullColIndex(sheet, activeRowIndex, startSearchIndex);
        }

        if (activePosition === ActiveCellPositionInRange.end) {
            selNeedAdjust.colCount = activeColIndex - findResult + 1;
        } else if (activePosition === ActiveCellPositionInRange.start) {
            selNeedAdjust.colCount = Math.abs(findResult - activeColIndex) + 1;
        } else {
            selNeedAdjust.colCount = selNeedAdjust.col + selNeedAdjust.colCount - findResult;
        }
        if (findResult < activeColIndex) {
            selNeedAdjust.col = findResult;
        } else if (activePosition !== ActiveCellPositionInRange.middle) {
            selNeedAdjust.col = activeColIndex;
        }
        expand_Selection(sheet, selNeedAdjust);
        sheet.showCell(activeRowIndex, selNeedAdjust.col, VerticalPosition.nearest, HorizontalPosition.nearest);
        sheet.resumePaint();
    }
    return true;
}

function selectionEndExecute (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
    let sheet = Util.getSheet(context, options), sheetColCount = sheet.getColumnCount(),
        selections = options.selections || sheet.getSelections(), activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(),
        activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
    if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
        return false;
    }
    if (sheet.editorStatus() !== 0) {
        return (sheet as any).changeFormulaTextCtrlShift(sheet, 4 /* right */);
    }
    let selNeedAdjust = Util.getNeedAdjustSelection(selections, activeRowIndex, activeColIndex);
    if (selNeedAdjust !== null) {
        let activePosition = Util.getCellPositionInRangeByCol(selNeedAdjust, activeColIndex);
        if (activePosition === ActiveCellPositionInRange.middle && selNeedAdjust.col === -1) {
            return true;
        }
        sheet.suspendPaint();
        let findResult, lastColIndex, nextVisibleColIndex;

        if (activePosition === ActiveCellPositionInRange.end) {
            lastColIndex = selNeedAdjust.col;
        } else if (activePosition === ActiveCellPositionInRange.start) {
            lastColIndex = selNeedAdjust.col + selNeedAdjust.colCount - 1;
        } else {
            lastColIndex = selNeedAdjust.col + selNeedAdjust.colCount - 1;
        }

        let startSearchIndex = activePosition === ActiveCellPositionInRange.end ? (selNeedAdjust.col + 1) : (selNeedAdjust.col + selNeedAdjust.colCount);

        nextVisibleColIndex = lastColIndex + 1;
        while (nextVisibleColIndex < sheetColCount && !sheet.getColumnVisible(nextVisibleColIndex)) {
            nextVisibleColIndex++;
        }
        let LastCellNonNull = Util.hasValue(sheet, activeRowIndex, lastColIndex);
        let nextCellNonNull = Util.hasValue(sheet, activeRowIndex, nextVisibleColIndex);
        let acrossCellsBlock = LastCellNonNull && nextCellNonNull;

        if (acrossCellsBlock) {
            findResult = Util.findLastNotNullColIndexInRange(sheet, activeRowIndex, startSearchIndex);
        } else {
            findResult = Util.findNextNotNullColIndex(sheet, activeRowIndex, startSearchIndex);
        }

        if (activePosition === ActiveCellPositionInRange.end) {
            selNeedAdjust.colCount = Math.abs(findResult - activeColIndex) + 1;
        } else if (activePosition === ActiveCellPositionInRange.start) {
            selNeedAdjust.colCount = findResult - activeColIndex + 1;
        } else {
            selNeedAdjust.colCount = findResult - selNeedAdjust.col + 1;
        }
        if (findResult < activeColIndex) {
            selNeedAdjust.col = findResult;
        } else if (activePosition !== ActiveCellPositionInRange.middle) {
            selNeedAdjust.col = activeColIndex;
        }
        expand_Selection(sheet, selNeedAdjust);
        sheet.showCell(activeRowIndex, selNeedAdjust.col + selNeedAdjust.colCount - 1, VerticalPosition.nearest, HorizontalPosition.nearest);
        sheet.resumePaint();
    }
    return true;
}

Commands[SELECTION_HOME] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (sheet.options.rightToLeft) {
            return selectionEndExecute(context, options, isUndo);
        } else {
            return selectionHomeExecute(context, options, isUndo);
        }
    }
};

Commands[SELECTION_END] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (sheet.options.rightToLeft) {
            return selectionHomeExecute(context, options, isUndo);
        } else {
            return selectionEndExecute(context, options, isUndo);
        }
    }
};

Commands[SELECTION_TOP] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options), selections = options.selections || sheet.getSelections(),
        activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(),
        activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
        if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
            return false;
        }
        if (sheet.editorStatus() !== 0) {
            return (sheet as any).changeFormulaTextCtrlShift(sheet, 1 /* up */);
        }
        let selNeedAdjust = Util.getNeedAdjustSelection(selections, activeRowIndex, activeColIndex);
        if (selNeedAdjust !== null) {
            let activePosition = Util.getCellPositionInRangeByRow(selNeedAdjust, activeRowIndex);
            if (activePosition === ActiveCellPositionInRange.middle && selNeedAdjust.row === -1) {
                return true;
            }
            sheet.suspendPaint();
            let findResult, lastRowIndex, nextVisibleRowIndex;

            if (activePosition === ActiveCellPositionInRange.end) {
                lastRowIndex = selNeedAdjust.row;
            } else if (activePosition === ActiveCellPositionInRange.start) {
                lastRowIndex = selNeedAdjust.row + selNeedAdjust.rowCount - 1;
            } else {
                lastRowIndex = selNeedAdjust.row;
            }

            let startSearchIndex = activePosition === ActiveCellPositionInRange.start ? (selNeedAdjust.row + selNeedAdjust.rowCount - 1 - 1) : (selNeedAdjust.row - 1);

            nextVisibleRowIndex = lastRowIndex - 1;
            while (nextVisibleRowIndex >= 0 && !sheet.getRowVisible(nextVisibleRowIndex)) {
                nextVisibleRowIndex--;
            }
            let LastCellNonNull = Util.hasValue(sheet, lastRowIndex, activeColIndex);
            let nextCellNonNull = Util.hasValue(sheet, nextVisibleRowIndex, activeColIndex);
            let acrossCellsBlock = LastCellNonNull && nextCellNonNull;

            if (acrossCellsBlock) {
                findResult = Util.findFirstNotNullRowIndexInRange(sheet, activeColIndex, startSearchIndex);
            } else {
                findResult = Util.findPreviousNotNullRowIndex(sheet, activeColIndex, startSearchIndex);
            }

            if (activePosition === ActiveCellPositionInRange.end) {
                selNeedAdjust.rowCount = activeRowIndex - findResult + 1;
            } else if (activePosition === ActiveCellPositionInRange.start) {
                selNeedAdjust.rowCount = Math.abs(findResult - activeRowIndex) + 1;
            } else {
                selNeedAdjust.rowCount = selNeedAdjust.row + selNeedAdjust.rowCount - findResult;
            }
            if (findResult < activeRowIndex) {
                selNeedAdjust.row = findResult;
            } else if (activePosition !== ActiveCellPositionInRange.middle) {
                selNeedAdjust.row = activeRowIndex;
            }
            expand_Selection(sheet, selNeedAdjust);
            sheet.showCell(selNeedAdjust.row, activeColIndex, VerticalPosition.nearest, HorizontalPosition.nearest);
            sheet.resumePaint();
        }
        return true;
    }
};

Commands[SELECTION_BOTTOM] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options), sheetRowCount = sheet.getRowCount(),
            selections = options.selections || sheet.getSelections(), activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(),
            activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
        if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
            return false;
        }
        if (sheet.editorStatus() !== 0) {
            return (sheet as any).changeFormulaTextCtrlShift(sheet, 2 /* down */);
        }
        let selNeedAdjust = Util.getNeedAdjustSelection(selections, activeRowIndex, activeColIndex);
        if (selNeedAdjust) {
            let activePosition = Util.getCellPositionInRangeByRow(selNeedAdjust, activeRowIndex);
            if (activePosition === ActiveCellPositionInRange.middle && selNeedAdjust.row === -1) {
                return true;
            }
            sheet.suspendPaint();
            let findResult, lastRowIndex, nextVisibleRowIndex;

            if (activePosition === ActiveCellPositionInRange.end) {
                lastRowIndex = selNeedAdjust.row;
            } else if (activePosition === ActiveCellPositionInRange.start) {
                lastRowIndex = selNeedAdjust.row + selNeedAdjust.rowCount - 1;
            } else {
                lastRowIndex = selNeedAdjust.row + selNeedAdjust.rowCount - 1;
            }

            let startSearchIndex = activePosition === ActiveCellPositionInRange.end ? (selNeedAdjust.row + 1) : (selNeedAdjust.row + selNeedAdjust.rowCount);

            nextVisibleRowIndex = lastRowIndex + 1;
            while (nextVisibleRowIndex < sheetRowCount && !sheet.getRowVisible(nextVisibleRowIndex)) {
                nextVisibleRowIndex++;
            }
            let LastCellNonNull = Util.hasValue(sheet, lastRowIndex, activeColIndex);
            let nextCellNonNull = Util.hasValue(sheet, nextVisibleRowIndex, activeColIndex);
            let acrossCellsBlock = LastCellNonNull && nextCellNonNull;

            if (acrossCellsBlock) {
                findResult = Util.findLastNotNullRowIndexInRange(sheet, activeColIndex, startSearchIndex);
            } else {
                findResult = Util.findNextNotNullRowIndex(sheet, activeColIndex, startSearchIndex);
            }

            if (activePosition === ActiveCellPositionInRange.end) {
                selNeedAdjust.rowCount = Math.abs(findResult - activeRowIndex) + 1;
            } else if (activePosition === ActiveCellPositionInRange.start) {
                selNeedAdjust.rowCount = findResult - activeRowIndex + 1;
            } else {
                selNeedAdjust.rowCount = findResult - selNeedAdjust.row + 1;
            }
            if (findResult < activeRowIndex) {
                selNeedAdjust.row = findResult;
            } else if (activePosition !== ActiveCellPositionInRange.middle) {
                selNeedAdjust.row = activeRowIndex;
            }
            expand_Selection(sheet, selNeedAdjust);
            sheet.showCell(selNeedAdjust.row + selNeedAdjust.rowCount - 1, activeColIndex, VerticalPosition.nearest, HorizontalPosition.nearest);
            sheet.resumePaint();
        }
        return true;
    }
};

Commands[GOTO_NEXT_TOP_NON_NULL_CELL] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options),
            activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(), activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
        if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
            return false;
        }
        if (sheet.editorStatus() !== 0) {
            return (sheet as any).changeFormulaText(sheet, 1 /* up */);
        }
        let stopIndex = 0, currentCellNonNull = Util.hasValue(sheet, activeRowIndex, activeColIndex);
        let rowIndex = activeRowIndex, colIndex = activeColIndex;
        if (rowIndex - 1 < stopIndex) {
            return true;
        }
        rowIndex--;
        while (rowIndex >= stopIndex && !sheet.getRowVisible(rowIndex)) {
            rowIndex--;
        }
        if (rowIndex < 0) {
            return true;
        }
        let acrossCellsBlock = currentCellNonNull && Util.hasValue(sheet, rowIndex, colIndex);
        if (acrossCellsBlock) {
            rowIndex = Util.findFirstNotNullRowIndexInRange(sheet, colIndex, rowIndex);
        } else {
            rowIndex = Util.findPreviousNotNullRowIndex(sheet, colIndex, rowIndex);
        }
        sheet.suspendPaint();
        sheet.setActiveCell(rowIndex, colIndex);
        sheet.showCell(rowIndex, colIndex, VerticalPosition.nearest, HorizontalPosition.nearest);
        sheet.resumePaint();
        return true;
    }
};

Commands[GOTO_NEXT_BOTTOM_NON_NULL_CELL] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options), rowCount = sheet.getRowCount(),
            activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(), activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
        if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
            return false;
        }
        if (sheet.editorStatus() !== 0) {
            return (sheet as any).changeFormulaText(sheet, 2 /* down */);
        }
        let stopIndex = sheet.getRowCount(), currentCellNonNull = Util.hasValue(sheet, activeRowIndex, activeColIndex);
        let rowIndex = activeRowIndex, colIndex = activeColIndex;
        if (rowIndex + 1 >= stopIndex) {
            return true;
        }
        rowIndex++;
        while (rowIndex < stopIndex && !sheet.getRowVisible(rowIndex)) {
            rowIndex++;
        }
        if (rowIndex >= rowCount) {
            return true;
        }
        let acrossCellsBlock = currentCellNonNull && Util.hasValue(sheet, rowIndex, colIndex);
        if (acrossCellsBlock) {
            rowIndex = Util.findLastNotNullRowIndexInRange(sheet, colIndex, rowIndex);
        } else {
            rowIndex = Util.findNextNotNullRowIndex(sheet, colIndex, rowIndex);
        }
        sheet.suspendPaint();
        sheet.setActiveCell(rowIndex, colIndex);
        sheet.showCell(rowIndex, colIndex, VerticalPosition.nearest, HorizontalPosition.nearest);
        sheet.resumePaint();
        return true;
    }
};

function gotoNextLeftNonNullCellExecute (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
    let sheet = Util.getSheet(context, options),
        activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(), activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
    if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
        return false;
    }
    if (sheet.editorStatus() !== 0) {
        return (sheet as any).changeFormulaText(sheet, 3 /* left */);
    }
    let stopIndex = 0, currentCellNonNull = Util.hasValue(sheet, activeRowIndex, activeColIndex);
    let rowIndex = activeRowIndex, colIndex = activeColIndex;
    if (colIndex - 1 < stopIndex) {
        return true;
    }
    colIndex--;
    while (colIndex >= stopIndex && !sheet.getColumnVisible(colIndex)) {
        colIndex--;
    }
    if (colIndex < 0) {
        return true;
    }
    let acrossCellsBlock = currentCellNonNull && Util.hasValue(sheet, rowIndex, colIndex);
    if (acrossCellsBlock) {
        colIndex = Util.findFirstNotNullColIndexInRange(sheet, rowIndex, colIndex);
    } else {
        colIndex = Util.findPreviousNotNullColIndex(sheet, rowIndex, colIndex);
    }
    sheet.suspendPaint();
    sheet.setActiveCell(rowIndex, colIndex);
    sheet.showCell(rowIndex, colIndex, VerticalPosition.nearest, HorizontalPosition.nearest);
    sheet.resumePaint();
    return true;
}

function gotoNextRightNonNullCellExecute (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
    let sheet = Util.getSheet(context, options), colCount = sheet.getColumnCount(),
        activeRowIndex = options.activeRowIndex ?? sheet.getActiveRowIndex(), activeColIndex = options.activeColIndex ?? sheet.getActiveColumnIndex();
    if (Util.hasSelectedShapeOrFloatingObject(sheet)) {
        return false;
    }
    if (sheet.editorStatus() !== 0) {
        return (sheet as any).changeFormulaText(sheet, 4 /* right */);
    }
    let stopIndex = colCount, currentCellNonNull = Util.hasValue(sheet, activeRowIndex, activeColIndex);
    let rowIndex = activeRowIndex, colIndex = activeColIndex;
    if (colIndex + 1 >= stopIndex) {
        return true;
    }
    colIndex++;
    while (colIndex < stopIndex && !sheet.getColumnVisible(colIndex)) {
        colIndex++;
    }
    if (colIndex >= colCount) {
        return true;
    }
    let acrossCellsBlock = currentCellNonNull && Util.hasValue(sheet, rowIndex, colIndex);
    if (acrossCellsBlock) {
        colIndex = Util.findLastNotNullColIndexInRange(sheet, rowIndex, colIndex);
    } else {
        colIndex = Util.findNextNotNullColIndex(sheet, rowIndex, colIndex);
    }
    sheet.suspendPaint();
    sheet.setActiveCell(rowIndex, colIndex);
    sheet.showCell(rowIndex, colIndex, VerticalPosition.nearest, HorizontalPosition.nearest);
    sheet.resumePaint();
    return true;
}

Commands[GOTO_NEXT_LEFT_NON_NULL_CELL] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (sheet.options.rightToLeft) {
            return gotoNextRightNonNullCellExecute(context, options, isUndo);
        } else {
            return gotoNextLeftNonNullCellExecute(context, options, isUndo);
        }
    }
};

Commands[GOTO_NEXT_RIGHT_NON_NULL_CELL] = {
    canUndo: false,
    execute: function (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        let sheet = Util.getSheet(context, options);
        if (sheet.options.rightToLeft) {
            return gotoNextLeftNonNullCellExecute(context, options, isUndo);
        } else {
            return gotoNextRightNonNullCellExecute(context, options, isUndo);
        }
    }
};

export function initShortcutAboutSelection (commands: GC.Spread.Commands.CommandManager) {
    let isMac = Util._isMacOS(), ctrl = !isMac, meta = isMac;

    commands.register(SELECT_ENTIRE_ROW, Commands[SELECT_ENTIRE_ROW], 32 /* SPACE*/, false /* ctrl */, true /* shift */, false /* alt */, false /* meta */);
    commands.register(SELECT_ENTIRE_COLUMN, Commands[SELECT_ENTIRE_COLUMN], 32 /* SPACE */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(GO_SHEET_BEGINNING, Commands[GO_SHEET_BEGINNING], 36 /* HOME */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(GO_SHEET_BOTTOM_RIGHT, Commands[GO_SHEET_BOTTOM_RIGHT], 35 /* END */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(GO_TO_DEPENDENTS, Commands[GO_TO_DEPENDENTS], 221 /* ] */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(GO_TO_PRECEDENTS, Commands[GO_TO_PRECEDENTS], 219 /* [ */, ctrl, false /* shift */, false /* alt */, meta);
    commands.register(SELECT_ALL, Commands[SELECT_ALL], 65 /* A */, ctrl, false /* shift */, false /* alt */, meta);
    if (Util.isFirefox()) {
        commands.register(SELECT_VISIBLE_CELLS, Commands[SELECT_VISIBLE_CELLS], 59 /* semicolon */, false /* ctrl */, false /* shift */, true /* alt */, false /* meta */);
    } else {
        commands.register(SELECT_VISIBLE_CELLS, Commands[SELECT_VISIBLE_CELLS], 186 /* semicolon */, false /* ctrl */, false /* shift */, true /* alt */, false /* meta */);
    }
    commands.register(SELECTION_HOME, Commands[SELECTION_HOME], 37 /* left */, ctrl, true /* shift */, false /* alt */, meta);
    commands.register(SELECTION_END, Commands[SELECTION_END], 39 /* right */, ctrl, true /* shift */, false /* alt */, meta);
    commands.register(SELECTION_TOP, Commands[SELECTION_TOP], 38 /* up */, ctrl, true /* shift */, false /* alt */, meta);
    commands.register(SELECTION_BOTTOM, Commands[SELECTION_BOTTOM], 40 /* down */, ctrl, true /* shift */, false /* alt */, meta);
    if ((commands as any).navigationTop) {
        commands.setShortcutKey("navigationTop");
    }
    commands.register(GOTO_NEXT_TOP_NON_NULL_CELL, Commands[GOTO_NEXT_TOP_NON_NULL_CELL], 38 /* up */, ctrl, false /* shift */, false /* alt */, meta);
    if ((commands as any).navigationBottom) {
        commands.setShortcutKey("navigationBottom");
    }
    commands.register(GOTO_NEXT_BOTTOM_NON_NULL_CELL, Commands[GOTO_NEXT_BOTTOM_NON_NULL_CELL], 40 /* down */, ctrl, false /* shift */, false /* alt */, meta);
    if ((commands as any).navigationHome2) {
        commands.setShortcutKey("navigationHome2");
    }
    commands.register(GOTO_NEXT_LEFT_NON_NULL_CELL, Commands[GOTO_NEXT_LEFT_NON_NULL_CELL], 37 /* left */, ctrl, false /* shift */, false /* alt */, meta);
    if ((commands as any).navigationEnd2) {
        commands.setShortcutKey("navigationEnd2");
    }
    commands.register(GOTO_NEXT_RIGHT_NON_NULL_CELL, Commands[GOTO_NEXT_RIGHT_NON_NULL_CELL], 39 /* right */, ctrl, false /* shift */, false /* alt */, meta);

}