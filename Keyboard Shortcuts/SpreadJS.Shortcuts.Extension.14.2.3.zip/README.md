
#SpreadJS shortcut command demo build

If you try to use shortcut, please execute the following step:
 - 1. update spreadJS version in package.json.
 - 2. npm install
 - 3. npm run build.
 - 4. the product is dist/spreadjs_shortcut_command.js

If you try to test these feature, please execute the following step:
 - 1. update spreadJS version in package.json.
 - 2. npm install
 - 3. npm run build.
 - 4. open the test/index.html.