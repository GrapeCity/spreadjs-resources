import * as GC from "@grapecity/spread-sheets";
let cultureInfo = new GC.Spread.Common.CultureInfo();
cultureInfo.id = 2057;
cultureInfo.displayName = "English (United Kingdom)";
cultureInfo.name = function () { return "en-GB"; };
cultureInfo.NumberFormat.currencyDecimalSeparator = ".";
cultureInfo.NumberFormat.currencyGroupSeparator = ",";
cultureInfo.NumberFormat.currencySymbol = "£";
cultureInfo.NumberFormat.numberDecimalSeparator = ".";
cultureInfo.NumberFormat.numberGroupSeparator = ",";
cultureInfo.NumberFormat.listSeparator = ",";
cultureInfo.NumberFormat.arrayListSeparator = ",";
cultureInfo.NumberFormat.arrayGroupSeparator = ";";
cultureInfo.DateTimeFormat.abbreviatedDayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
cultureInfo.DateTimeFormat.abbreviatedMonthGenitiveNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ""];
cultureInfo.DateTimeFormat.abbreviatedMonthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ""];
cultureInfo.DateTimeFormat.amDesignator = "am";
cultureInfo.DateTimeFormat.dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
cultureInfo.DateTimeFormat.fullDateTimePattern = "dddd, d MMMM yyyy HH:mm:ss";
cultureInfo.DateTimeFormat.longDatePattern = "dddd, d MMMM yyyy";
cultureInfo.DateTimeFormat.longTimePattern = "HH:mm:ss";
cultureInfo.DateTimeFormat.monthDayPattern = "d MMMM";
cultureInfo.DateTimeFormat.monthGenitiveNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ""];
cultureInfo.DateTimeFormat.monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ""];
cultureInfo.DateTimeFormat.pmDesignator = "pm";
cultureInfo.DateTimeFormat.shortDatePattern = "dd/MM/yyyy";
cultureInfo.DateTimeFormat.shortTimePattern = "HH:mm";
cultureInfo.DateTimeFormat.yearMonthPattern = "MMMM yyyy";
cultureInfo.predefinedFormats = {
    Accounting: '_-[$£-809]* #,##0._-;-[$£-809]* #,##0._-;_-[$£-809]* "-"._-;_-@_-',
    Currency: [
        "[$£-809]#,##0.",
        "[$£-809]#,##0.;[Red][$£-809]#,##0.",
        "[$£-809]#,##0.;-[$£-809]#,##0.",
        "[$£-809]#,##0.;[Red]-[$£-809]#,##0."
    ],
    Date: [
        "dd/mm/yyyy;@",
        "dd/mm/yy;@",
        "d/m/yy;@",
        "d.m.yy;@",
        "yyyy-mm-dd;@",
        "[$-809]dd mmmm yyyy;@",
        "[$-809]d mmmm yyyy;@",
    ],
    Time: [
        "hh:mm:ss;@",
        "h:mm:ss;@",
        "[$-809]hh:mm:ss AM/PM;@",
        "[$-809]h:mm:ss AM/PM;@"
    ],
};
export default cultureInfo;
