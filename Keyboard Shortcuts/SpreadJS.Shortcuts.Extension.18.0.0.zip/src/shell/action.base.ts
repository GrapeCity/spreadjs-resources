import * as GC from "@grapecity/spread-sheets";
import { Util } from "../common/util";

const keyword_undefined = void 0;
export interface IShortcutActionOptionBase {
    cmd?: string;
    sheetName: string;
    selections: GC.Spread.Sheets.Range[];
    activeRowIndex: number;
    activeColIndex: number;
}

interface ICommand {
    canUndo: boolean;
    execute: (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) => boolean;
}

interface ICommands {
    [key: string]: ICommand;
}

interface IEventArg {
    sheet: GC.Spread.Sheets.Worksheet;
    sheetName: string;
    sheetArea: number;
    row: number;
    col: number;
    cancel?: boolean;
    readonly?: boolean;
}

export let Commands: ICommands = {};

export abstract class ShortcutActionBase<T extends IShortcutActionOptionBase> {
    private _spread: GC.Spread.Sheets.Workbook;
    protected _options: T;

    constructor (spread: GC.Spread.Sheets.Workbook, options: T) {
        this._spread = spread;
        this._options = options;
    }

    canExecute (): boolean {
        return true;
    }
    canUndo (): boolean {
        return true;
    }

    abstract executeImp (): boolean;

    undoImp (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean) {
        context.suspendPaint();
        GC.Spread.Sheets.Commands.undoTransaction(context, options);
        context.resumePaint();
        return true;
    }

    execute (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase, isUndo: boolean): boolean {
        let self = this, flag = false;
        if (isUndo) {
            flag = self.undoImp.call(self, context, options, isUndo);
        } else if (self.canExecute()) {
            let commands = GC.Spread.Sheets.Commands;
            commands.startTransaction(context, options);
            context.suspendPaint();
            try {
                flag = self.executeImp();
            } finally {
                context.resumePaint();
                commands.endTransaction(context, options);
            }
        }
        return flag;
    }

    getSheet () {
        return Util.getSheet(this._spread, this._options);
    }

    getSpread () {
        return this._spread;
    }

    setCellStyle (func: (cell: GC.Spread.Sheets.CellRange) => void) {
        let self = this;
        let sheet = self.getSheet();
        let selections = self._options.selections;
        sheet.suspendPaint();
        selections.forEach((selection: GC.Spread.Sheets.Range) => {
            let { row, col, rowCount, colCount } = selection;
            let cellRange = sheet.getRange(row, col, rowCount, colCount);
            func(cellRange);
        });
        sheet.resumePaint();
    }

    getFontStyle (font: string, attribute: any, value: any) {
        let span = document.createElement("span");
        if (!font) {
            return value;
        } else {
            span.style.font = font;
        }
        span.style[attribute] = value;
        return span.style.font;
    }

    protected _canEditInActiveCell (): boolean {
        const self = this;
        const { activeRowIndex, activeColIndex } = self._options;
        const sheet = self.getSheet();

        if (self._isProtectCell(sheet, activeRowIndex, activeColIndex)) {
            return false;
        }
        if (self._isReadonlyCellType(sheet, activeRowIndex, activeColIndex)) {
            return false;
        }
        return self._isAllowEditInCell(sheet, activeRowIndex, activeColIndex);
    }

    private _isProtectCell (sheet: any, row: number, col: number) {
        if (sheet.isActualProtected()) {
            let style = sheet.getActualStyle(row, col);
            if (style) {
                return style.locked !== false;
            }
        }
        return false;
    }

    private _isReadonlyCellType (sheet: GC.Spread.Sheets.Worksheet, row: number, col: number) {
        let cellType: any = sheet.getCellType(row, col);
        if (cellType) {
            let arg: IEventArg = {
                sheet: sheet,
                sheetName: sheet.name(),
                sheetArea: GC.Spread.Sheets.SheetArea.viewport,
                readonly: false,
                row: row,
                col: col
            };
            return cellType.isReadonly(arg);
        }
        return false;
    }

    private _isAllowEditInCell (sheet: GC.Spread.Sheets.Worksheet, row: number, col: number) {
        const style = sheet.getActualStyle(row, col);
        if (style) {
            return style.allowEditInCell !== false;
        }
        return true;
    }
}

export function executeCommand (context: GC.Spread.Sheets.Workbook, action: any, options: IShortcutActionOptionBase, isUndo: boolean | undefined): boolean {
    let sheet = Util.getSheet(context, options);
    if (!options.selections) {
        options.selections = sheet.getSelections();
    }
    if (options.activeRowIndex === undefined) {
        options.activeRowIndex = sheet.getActiveRowIndex();
    }
    if (options.activeColIndex === undefined) {
        options.activeColIndex = sheet.getActiveColumnIndex();
    }
    let cmd = new action(context, options) as ShortcutActionBase<IShortcutActionOptionBase>;
    return cmd.execute(context, options, !!isUndo);
}