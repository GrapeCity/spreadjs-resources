var path = require("path");
var ROOT_PATH = path.resolve(__dirname, '.');
var srcPath = path.resolve(ROOT_PATH, 'npmImage');
var fileOperation = require('./fileOperater.js');
var copyFiles = fileOperation.copyFiles;
var removeFolder = fileOperation.removeFolder;
var copyFolder = fileOperation.copyFolder;

var target = path.resolve(ROOT_PATH, "../dist/npmImage");

//Step 1: Remove npmImage folder.
removeFolder(path.resolve(target));

//Step 2:  Copy npm content folder structure to output npmImage folder
copyFolder(srcPath, target);

var dist = [
    { src: 'dist/spreadjs.globalization.min.js', tar: 'sjs-globalization/dist/' }
];

dist.forEach(function (dir) {
    var root = target;
    dir.tar = path.resolve(root, dir.tar);
    copyFiles(dir.src, dir.tar);
});