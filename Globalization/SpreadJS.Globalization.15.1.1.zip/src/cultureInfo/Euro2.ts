import * as GC from "@grapecity/spread-sheets";
let cultureInfo = new GC.Spread.Common.CultureInfo();
cultureInfo.id = -1;
cultureInfo.displayName = "Euro (€ 123)";
cultureInfo.name = function () { return "Euro2"; };
cultureInfo.NumberFormat.currencyDecimalSeparator = ".";
cultureInfo.NumberFormat.currencyGroupSeparator = ",";
cultureInfo.NumberFormat.currencySymbol = "€";
cultureInfo.NumberFormat.numberDecimalSeparator = ".";
cultureInfo.NumberFormat.numberGroupSeparator = ",";
cultureInfo.NumberFormat.listSeparator = ",";
cultureInfo.NumberFormat.arrayListSeparator = ",";
cultureInfo.NumberFormat.arrayGroupSeparator = ";";
cultureInfo.DateTimeFormat.abbreviatedDayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
cultureInfo.DateTimeFormat.abbreviatedMonthGenitiveNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ""];
cultureInfo.DateTimeFormat.abbreviatedMonthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", ""];
cultureInfo.DateTimeFormat.amDesignator = "AM";
cultureInfo.DateTimeFormat.dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
cultureInfo.DateTimeFormat.fullDateTimePattern = "dddd, MMMM d, yyyy h:mm:ss tt";
cultureInfo.DateTimeFormat.longDatePattern = "dddd, MMMM d, yyyy";
cultureInfo.DateTimeFormat.longTimePattern = "h:mm:ss tt";
cultureInfo.DateTimeFormat.monthDayPattern = "MMMM d";
cultureInfo.DateTimeFormat.monthGenitiveNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ""];
cultureInfo.DateTimeFormat.monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ""];
cultureInfo.DateTimeFormat.pmDesignator = "PM";
cultureInfo.DateTimeFormat.shortDatePattern = "M/d/yyyy";
cultureInfo.DateTimeFormat.shortTimePattern = "h:mm tt";
cultureInfo.DateTimeFormat.yearMonthPattern = "MMMM yyyy";
cultureInfo.predefinedFormats = {
    Accounting: '_([$€-x-euro2] * #,##0.00_);_([$€-x-euro2] * (#,##0.00);_([$€-x-euro2] * "-"??_);_(@_)',
    Currency: [
        "[$€-x-euro2] #,##0.",
        "[$€-x-euro2] #,##0.;[Red][$€-x-euro2] #,##0.",
        "[$€-x-euro2] #,##0._);([$€-x-euro2] #,##0.)",
        "[$€-x-euro2] #,##0._);[Red]([$€-x-euro2] #,##0.)",
    ]
};
export default cultureInfo;
