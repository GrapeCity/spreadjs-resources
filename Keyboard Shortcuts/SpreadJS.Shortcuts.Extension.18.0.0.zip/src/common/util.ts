import * as GC from "@grapecity/spread-sheets";
import { RangeType } from "../shortcut/action.row.column";
import { IShortcutActionOptionBase } from "../shell/action.base";

interface IFontInfo {
    fontStyle: string;
    fontWeight: string;
    lineHeight: string;
}

interface IClosedInterval {
    startIndex: number;
    endIndex: number;
}

export const enum ActiveCellPositionInRange {
    start = 0,
    middle = 1,
    end = 2,
}

export class Util {
    static parseFont (font: string): IFontInfo {
        let fontStyle = '', fontWeight = 'normal',
            lineHeight = 'normal';
        let elements = font.split(/\s+/);
        for (let element of elements) {
            switch (element) {
                case "normal":
                    break;
                case "italic":
                    if (fontStyle.indexOf("bold") !== -1) {
                        fontStyle = "bold italic";
                    } else {
                        fontStyle = element;
                    }
                    break;
                case "bold":
                    if (fontStyle.indexOf("italic") !== -1) {
                        fontStyle = "bold italic";
                    } else {
                        fontStyle = element;
                    }
                    fontWeight = "bold";
                    break;
                case "100":
                case "200":
                case "300":
                case "400":
                case "500":
                case "600":
                case "700":
                case "800":
                case "900":
                    fontWeight = element;
                    break;
                case "lighter":
                    fontWeight = "lighter";
                    break;
            }
        }
        if (!fontStyle) {
            fontStyle = "normal";
        }
        return {
            fontStyle: fontStyle,
            fontWeight: fontWeight,
            lineHeight: lineHeight,
        };
    }

    static _isMacOS (): boolean {
        let platform = navigator.platform;
        return (platform && platform.indexOf('Mac') > -1) as boolean;
    }

    static getActiveCellStyle (sheet: GC.Spread.Sheets.Worksheet, rowIndex: number, colIndex: number) {
        return sheet.getActualStyle(rowIndex, colIndex);
    }

    static getInvisibleInfo (infos: boolean[]): number[] {
        let result = [];
        for (let i = 0; i < infos.length; i++) {
            let info = infos[i];
            if (info) {
                result.push(i);
            }
        }
        return result;
    }

    static getNextStartIndex (arr: number[], index: number): number {
        let num = arr[index];
        do {
            index++;
            num++;
        } while (num === arr[index]);
        return num;
    }

    static getContinuousVisibleInterval (totalLength: number, array: number[]): IClosedInterval[] {
        let result: IClosedInterval[] = [];
        array = array.sort((first: number, last: number) => first - last);
        let startIndex = 0, endIndex = 0;
        while (endIndex < totalLength) {
            if (array.indexOf(endIndex) > -1) {
                result.push({
                    startIndex: startIndex,
                    endIndex: endIndex - 1,
                });
                let nextStartIndex = Util.getNextStartIndex(array, array.indexOf(endIndex));
                startIndex = endIndex = nextStartIndex;
            } else {
                endIndex++;
            }
        }
        if (startIndex < endIndex) {
            result.push({
                startIndex: startIndex,
                endIndex: endIndex - 1,
            });
        }
        return result;
    }
    static removeHiddenRegions (selection: GC.Spread.Sheets.Range[], hiddenCols: boolean[], hiddenRows: boolean[]): GC.Spread.Sheets.Range[] {
        let result: GC.Spread.Sheets.Range[] = [];

        selection.forEach((sel) => {
            let { row, rowCount, col, colCount } = sel;
            if (col === -1) {
                col = 0;
            }
            if (row === -1) {
                row = 0;
            }
            let visibleCols = [];
            for (let c = col; c < col + colCount; c++) {
                if (!hiddenCols[c]) {
                    visibleCols.push(c);
                }
            }

            let visibleRows = [];
            for (let r = row; r < row + rowCount; r++) {
                if (!hiddenRows[r]) {
                    visibleRows.push(r);
                }
            }

            if (visibleRows.length > 0 && visibleCols.length > 0) {
                let startRow = visibleRows[0];
                let rowLength = 1;

                for (let i = 1; i < visibleRows.length; i++) {
                    if (visibleRows[i] === visibleRows[i - 1] + 1) {
                        rowLength++;
                    } else {
                        this.addVisibleRegions(result, startRow, rowLength, visibleCols);
                        startRow = visibleRows[i];
                        rowLength = 1;
                    }
                }
                this.addVisibleRegions(result, startRow, rowLength, visibleCols);
            }
        });

        return result;
    }

    static addVisibleRegions (result: GC.Spread.Sheets.Range[], row: number, rowCount: number, visibleCols: number[]): void {
        let startCol = visibleCols[0];
        let colLength = 1;

        for (let i = 1; i < visibleCols.length; i++) {
            if (visibleCols[i] === visibleCols[i - 1] + 1) {
                colLength++;
            } else {
                result.push({
                    row: row,
                    rowCount: rowCount,
                    col: startCol,
                    colCount: colLength
                } as GC.Spread.Sheets.Range);
                startCol = visibleCols[i];
                colLength = 1;
            }
        }

        result.push({
            row: row,
            rowCount: rowCount,
            col: startCol,
            colCount: colLength
        } as GC.Spread.Sheets.Range);
    }
    static hasHiddenRowsOrCols (selection: GC.Spread.Sheets.Range[], hiddenCols: boolean[], hiddenRows: boolean[]): boolean {
        for (let sel of selection) {
            let { row, rowCount, col, colCount } = sel;

            for (let c = col; c < col + colCount; c++) {
                if (hiddenCols[c]) {
                    return true;
                }
            }
            for (let r = row; r < row + rowCount; r++) {
                if (hiddenRows[r]) {
                    return true;
                }
            }
        }
        return false;
    }

    static getInvisibleRange (sheet: GC.Spread.Sheets.Worksheet) {
        let result: GC.Spread.Sheets.Range[] = [];
        let rowInfos = this.getAxisInfo(sheet, true);
        let colInfos = this.getAxisInfo(sheet, false);
        let selections = sheet.getSelections();
        if (this.hasHiddenRowsOrCols(selections, colInfos, rowInfos)) {
            result = this.removeHiddenRegions(sheet.getSelections(), colInfos, rowInfos);
        } else if (selections.length === 1 && selections[0].rowCount === 1 && selections[0].colCount === 1) {
            let invisibleCols = this.getInvisibleInfo(colInfos);
            let invisibleRows = this.getInvisibleInfo(rowInfos);
            if (invisibleCols.length !== 0 || invisibleRows.length !== 0) {
                let continuousInvisibleRows = this.getContinuousVisibleInterval(sheet.getRowCount(), invisibleRows);
                let continuousInvisibleColumns = this.getContinuousVisibleInterval(sheet.getColumnCount(), invisibleCols);
                continuousInvisibleRows.forEach((invisibleRowInterval) => {
                    continuousInvisibleColumns.forEach((invisibleColInterval) => {
                        let startRowIndex = invisibleRowInterval.startIndex, rowCount = invisibleRowInterval.endIndex - startRowIndex + 1;
                        let startColIndex = invisibleColInterval.startIndex, colCount = invisibleColInterval.endIndex - startColIndex + 1;
                        let range = new GC.Spread.Sheets.Range(startRowIndex, startColIndex, rowCount, colCount);
                        result.push(range);
                    });
                });
            }
        }
        return result;
    }

    static getRangeType (range: GC.Spread.Sheets.Range): RangeType {
        let row = range.row;
        let col = range.col;
        if (row === -1) {
            if (col === -1) {
                return RangeType.entireSheet;
            } else {
                return RangeType.fullColumn;
            }
        } else {
            if (col === -1) {
                return RangeType.fullRow;
            } else {
                return RangeType.singleRange;
            }
        }
    }

    static getAxisInfo (sheet: GC.Spread.Sheets.Worksheet, isRow: boolean) {
        let result = [];
        if (isRow) {
            let rowCount = sheet.getRowCount();
            for (let i = 0; i < rowCount; i++) {
                let rowHeight = sheet.getRowHeight(i);
                result.push(rowHeight === 0);
            }
        } else {
            let colCount = sheet.getColumnCount();
            for (let i = 0; i < colCount; i++) {
                let colWidth = sheet.getColumnWidth(i);
                result.push(colWidth === 0);
            }
        }
        return result;
    }

    static isFirefox (): boolean {
        return !!navigator.userAgent.match(/Firefox/g);
    }

    static getBrowserCulture (): string {
        return navigator.language;
    }

    static getNeedAdjustSelection (selections: GC.Spread.Sheets.Range[], rowIndex: number, colIndex: number) {
        let sel = null;
        for (let selItem of selections) {
            if (selItem.contains(rowIndex, colIndex, 1, 1)) {
                sel = selItem;
            }
        }
        return sel;
    }

    static getCellPositionInRangeByCol (range: GC.Spread.Sheets.Range, activeColIndex: number) {
        let activePosition;
        if (activeColIndex === range.col || range.col === -1 && activeColIndex === 0) {
            activePosition = ActiveCellPositionInRange.start;
        } else if (activeColIndex === range.col + range.colCount - 1 || range.col === -1 && activeColIndex === range.colCount - 1) {
            activePosition = ActiveCellPositionInRange.end;
        } else {
            activePosition = ActiveCellPositionInRange.middle;
        }
        return activePosition;
    }

    static getCellPositionInRangeByRow (range: GC.Spread.Sheets.Range, activeRowIndex: number) {
        let activePosition;
        if (activeRowIndex === range.row || range.row === -1 && activeRowIndex === 0) {
            activePosition = ActiveCellPositionInRange.start;
        } else if (activeRowIndex === range.row + range.rowCount - 1 || range.row === -1 && activeRowIndex === range.rowCount - 1) {
            activePosition = ActiveCellPositionInRange.end;
        } else {
            activePosition = ActiveCellPositionInRange.middle;
        }
        return activePosition;
    }

    static hasValue (sheet: GC.Spread.Sheets.Worksheet, row: number, col: number) {
        return sheet.getValue(row, col) !== null || ((sheet as any).isReportTemplateSheet && !!(sheet as any).getTemplateCell(row, col));
    }

    static findPreviousNotNullColIndex (sheet: GC.Spread.Sheets.Worksheet, fixRow: number, colIndex: number) {
        let lastVisibleColumn = colIndex, stop = 0;
        while (colIndex >= stop) {
            if (sheet.getColumnVisible(colIndex)) {
                lastVisibleColumn = colIndex;
                if (this.hasValue(sheet, fixRow, colIndex)) {
                    break;
                }
            }
            colIndex--;
        }
        if (colIndex < stop) {
            colIndex = stop;
        }
        return sheet.getColumnVisible(colIndex) ? colIndex : lastVisibleColumn;
    }

    static findNextNotNullColIndex (sheet: GC.Spread.Sheets.Worksheet, fixRow: number, colIndex: number) {
        let lastVisibleColumn = colIndex, stop = sheet.getColumnCount();
        while (colIndex < stop) {
            if (sheet.getColumnVisible(colIndex)) {
                lastVisibleColumn = colIndex;
                if (this.hasValue(sheet, fixRow, colIndex)) {
                    break;
                }
            }
            colIndex++;
        }
        if (colIndex >= stop) {
            colIndex = stop - 1;
        }
        return sheet.getColumnVisible(colIndex) ? colIndex : lastVisibleColumn;
    }

    static findPreviousNotNullRowIndex (sheet: GC.Spread.Sheets.Worksheet, fixCol: number, rowIndex: number) {
        let lastVisibleRow = rowIndex, stop = 0;
        while (rowIndex >= stop) {
            if (sheet.getRowVisible(rowIndex)) {
                lastVisibleRow = rowIndex;
                if (this.hasValue(sheet, rowIndex, fixCol)) {
                    break;
                }
            }
            rowIndex--;
        }
        if (rowIndex < stop) {
            rowIndex = stop;
        }
        return sheet.getRowVisible(rowIndex) ? rowIndex : lastVisibleRow;
    }

    static findNextNotNullRowIndex (sheet: GC.Spread.Sheets.Worksheet, fixCol: number, rowIndex: number) {
        let lastVisibleRow = rowIndex, stop = sheet.getRowCount();
        while (rowIndex < stop) {
            if (sheet.getRowVisible(rowIndex)) {
                lastVisibleRow = rowIndex;
                if (this.hasValue(sheet, rowIndex, fixCol)) {
                    break;
                }
            }
            rowIndex++;
        }
        if (rowIndex >= stop) {
            rowIndex = stop - 1;
        }
        return sheet.getRowVisible(rowIndex) ? rowIndex : lastVisibleRow;
    }

    static findLastNotNullColIndexInRange (sheet: GC.Spread.Sheets.Worksheet, fixRow: number, colIndex: number) {
        let lastVisibleColumn = colIndex, stop = sheet.getColumnCount();
        while (colIndex < stop) {
            if (sheet.getColumnVisible(colIndex)) {
                if (this.hasValue(sheet, fixRow, colIndex)) {
                    lastVisibleColumn = colIndex;
                } else {
                    colIndex--;
                    break;
                }
            }
            colIndex++;
        }
        if (colIndex >= stop) {
            colIndex = stop - 1;
        }
        return sheet.getColumnVisible(colIndex) ? colIndex : lastVisibleColumn;
    }

    static findFirstNotNullColIndexInRange (sheet: GC.Spread.Sheets.Worksheet, fixRow: number, colIndex: number) {
        let lastVisibleColumn = colIndex, stop = 0;
        while (colIndex >= stop) {
            if (sheet.getColumnVisible(colIndex)) {
                if (this.hasValue(sheet, fixRow, colIndex)) {
                    lastVisibleColumn = colIndex;
                } else {
                    colIndex++;
                    break;
                }
            }
            colIndex--;
        }
        if (colIndex < stop) {
            colIndex = stop;
        }
        return sheet.getColumnVisible(colIndex) ? colIndex : lastVisibleColumn;
    }

    static findLastNotNullRowIndexInRange (sheet: GC.Spread.Sheets.Worksheet, fixCol: number, rowIndex: number) {
        let lastVisibleRow = rowIndex, stop = sheet.getRowCount();
        while (rowIndex < stop) {
            if (sheet.getRowVisible(rowIndex)) {
                if (this.hasValue(sheet, rowIndex, fixCol)) {
                    lastVisibleRow = rowIndex;
                } else {
                    rowIndex--;
                    break;
                }
            }
            rowIndex++;
        }
        if (rowIndex >= stop) {
            rowIndex = stop - 1;
        }
        return sheet.getRowVisible(rowIndex) ? rowIndex : lastVisibleRow;
    }

    static findFirstNotNullRowIndexInRange (sheet: GC.Spread.Sheets.Worksheet, fixCol: number, rowIndex: number) {
        let lastVisibleRow = rowIndex, stop = 0;
        while (rowIndex >= stop) {
            if (sheet.getRowVisible(rowIndex)) {
                if (this.hasValue(sheet, rowIndex, fixCol)) {
                    lastVisibleRow = rowIndex;
                } else {
                    rowIndex++;
                    break;
                }
            }
            rowIndex--;
        }
        if (rowIndex < stop) {
            rowIndex = stop;
        }
        return sheet.getRowVisible(rowIndex) ? rowIndex : lastVisibleRow;
    }

    static getSheet (context: GC.Spread.Sheets.Workbook, options: IShortcutActionOptionBase): GC.Spread.Sheets.Worksheet {
        let sheet = context.getSheetFromName(options.sheetName);
        if (sheet === undefined) {
            const sheetTab = context.getActiveSheetTab();
            if (sheetTab && typeof sheetTab.renderMode === 'function' && sheetTab.renderMode() === 'Design') {
                return sheetTab.getTemplate();
            }
        }
        return sheet;
    }

    static isRangeHasValue (sheet: GC.Spread.Sheets.Worksheet, range: GC.Spread.Sheets.Range): boolean {
        for (let row = range.row; row < range.row + range.rowCount; row++) {
            for (let col = range.col; col < range.col + range.colCount; col++) {
                let cell = sheet.getCell(row, col);
                if (!cell.text()) {
                    continue;
                } else {
                    return true;
                }
            }
        }
        return false;
    }

    static getActiveSelectedRange (selections: GC.Spread.Sheets.Range[], activeRowIndex: number, activeColIndex: number): GC.Spread.Sheets.Range | undefined {
        for (const selection of selections) {
            if (selection.contains(activeRowIndex, activeColIndex)) {
                return selection;
            }
        }
        return undefined;
    }

    static hasSelectedShape (sheet: GC.Spread.Sheets.Worksheet) {
        if (!sheet.shapes) {
            return false;
        }
        let shapes = sheet.shapes && sheet.shapes.all(), count = shapes.length;
        for (let i = 0; i < count; i++) {
            if (shapes[i] && shapes[i].isSelected()) {
                return true;
            }
        }
    }

    static hasSelectedChart (sheet: GC.Spread.Sheets.Worksheet) {
        if (!sheet.charts) {
            return false;
        }
        let charts = sheet.charts && sheet.charts.all(), count = charts.length;
        for (let i = 0; i < count; i++) {
            if (charts[i] && charts[i].isSelected()) {
                return true;
            }
        }
    }

    static hasSelectedPicture (sheet: GC.Spread.Sheets.Worksheet) {
        if (!sheet.pictures) {
            return false;
        }
        let pictures = sheet.pictures && sheet.pictures.all(), count = pictures.length;
        for (let i = 0; i < count; i++) {
            if (pictures[i] && pictures[i].isSelected()) {
                return true;
            }
        }
    }

    static hasSelectedSlicer (sheet: GC.Spread.Sheets.Worksheet) {
        if (!sheet.slicers) {
            return false;
        }
        let slicers = sheet.slicers && sheet.slicers.all(), count = slicers.length;
        for (let i = 0; i < count; i++) {
            if (slicers[i] && slicers[i].isSelected()) {
                return true;
            }
        }
    }

    static hasSelectedComment (sheet: GC.Spread.Sheets.Worksheet) {
        if (!sheet.comments) {
            return false;
        }
        let comments = sheet.comments && sheet.comments.all();
        for (const comment of comments) {
            let state = comment.commentState();
            if (state === GC.Spread.Sheets.Comments.CommentState.active || state === GC.Spread.Sheets.Comments.CommentState.edit) {
                return true;
            }
        }
    }

    static hasSelectedFloatingObject (sheet: GC.Spread.Sheets.Worksheet) {
        if (!sheet.floatingObjects) {
            return false;
        }
        let floatingObjects = sheet.floatingObjects && sheet.floatingObjects.all(), count = floatingObjects.length;
        for (let i = 0; i < count; i++) {
            if (floatingObjects[i] && floatingObjects[i].isSelected()) {
                return true;
            }
        }
    }

    static hasSelectedShapeOrFloatingObject (sheet: GC.Spread.Sheets.Worksheet): boolean {
        if (this.hasSelectedShape(sheet) || this.hasSelectedFloatingObject(sheet) || this.hasSelectedChart(sheet) || this.hasSelectedPicture(sheet) || this.hasSelectedSlicer(sheet) || this.hasSelectedComment(sheet)) {
            return true;
        }
        return false;
    }

    static needCheckProtectionOptions (sheet: GC.Spread.Sheets.Worksheet) {
        if (!sheet) {
            return false;
        }
        return (sheet as any).isActualProtected() && !!sheet.options.protectionOptions;
    }
    static containLockedCellsInSelections (sheet: GC.Spread.Sheets.Worksheet) {
        let selections = sheet.getSelections();
        let containLockedCellInSelections = false;
        let sheetRowCount = sheet.getRowCount(), sheetColCount = sheet.getColumnCount();
        for (let i = 0; i < selections.length; i++) {
            let { row, col } = selections[i];
            let { rowCount, colCount } = this.adjustSelection(sheet, selections[i], sheetRowCount, sheetColCount);
            if (this.containsLockedCellsInSelection(sheet, row, col, rowCount, colCount)) {
                containLockedCellInSelections = true;
            }
        }
        return containLockedCellInSelections;
    }
    static adjustSelection (sheet: GC.Spread.Sheets.Worksheet, selection: GC.Spread.Sheets.Range, sheetRowCount?: number, sheetColCount?: number) {
        let { row, col, rowCount, colCount } = selection;
        sheetRowCount = sheetRowCount ?? sheet.getRowCount() as number;
        sheetColCount = sheetColCount ?? sheet.getColumnCount() as number;
        if (row === -1) {
            row = 0;
            rowCount = sheetRowCount;
        }
        if (col === -1) {
            col = 0;
            colCount = sheetColCount;
        }
        rowCount = ((row + rowCount) > sheetRowCount) ? (sheetRowCount - row) : rowCount;
        colCount = ((col + colCount) > sheetColCount) ? (sheetColCount - col) : colCount;
        return new GC.Spread.Sheets.Range(row, col, rowCount, colCount);
    }
    static containsLockedCellsInSelection (sheet: GC.Spread.Sheets.Worksheet, row: number, column: number, rowCount: number, columnCount: number) {
        row = row < 0 ? 0 : row;
        column = column < 0 ? 0 : column;
        for (let i = row; i < row + rowCount; i++) {
            for (let j = column; j < column + columnCount; j++) {
                if (sheet.getCell(i, j).locked()) {
                    return true;
                }
            }
        }
    }
}