#SpreadJS shortcut command demo build

To implement the shortcuts in your app, follow these steps:
 - 1. Update the SpreadJS version in package.json to the latest version.
 - 2. npm install
 - 3. npm run build
 - 4. The result of the build will be dist/spreadjs_shortcut_command.js
 - 5. Add this file to your project

To test out the shortcuts in a simple HTML file, please execute the following step:
 - 1. Update the SpreadJS version in package.json to the latest version.
 - 2. npm install
 - 3. npm run build.
 - 4. Ppen the test/index.html file